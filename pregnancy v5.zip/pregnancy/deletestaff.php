<?php
require("conn.php");
$t=$_GET['key'];

$futa="DELETE FROM `admins` WHERE special_id='$t'";
$ff=mysqli_query($connect,$futa);



header("location:leaders.php");

?>