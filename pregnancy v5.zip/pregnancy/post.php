<?php
session_start();
require("conn.php");


$who=$_SESSION['who'];
$message="";

if(isset($_POST['kawaida'])){
    
    $title=$_POST['title'];
    $descr=$_POST['descr'];
    $cat=$_POST['cat'];
    $group=$_POST['group'];
    $notify=$_POST['ntf'];
  
   
     $when=date('d-m-Y h:i:sa');

// UPDATE `users` SET `first`='$first',`last`='$last',`age`='$age',`email`='$email',`photo`='$upd' WHERE `special_id`='$aidi'";

$al="INSERT INTO `post`(`title`, `description`,`categories`,`parentgroups`, `time`, `author`) VALUES ('$title','$descr','$cat','$group','$when','$who')";


 $isha=mysqli_query($connect,$al);
 
 if($isha){

     // check radio and sending notification
        if($notify=="yes"){ 
            $zzre="SELECT `id`,`phone` FROM `users`";
            $zzcfr=mysqli_query($connect,$zzre);
           
            $a=1;
            while ($zzfe=mysqli_fetch_array($zzcfr)) {
                 
                $aidi=$zzfe['id'];
                $nani=$zzfe['phone'];


                //start sms
                $api_key='8a998c13deb847b0';
                $secret_key = 'ZjU0MDQ3ZmUzYmIzMjAxMWVmNGRlNjRlM2NmM2M5NzZjMGQ2MGQ3OTIzNzhjMDlhZDhlNDRjMTk3MDQxNzdlYw==
                ';
                
                $postData = array(
                    'source_addr' => 'INFO',
                    'encoding'=>0,
                    'schedule_time' => '',
                    'message' => 'Taarifa ya posti | F.N.P.W.A , Habari tumeongeza taarifa mpya kuhusu '.$cat.' ya wazazi wa '.$group.', pitia kwenye mfumo kwa maelezo zaidi',
                    // 'recipients' => [array('recipient_id' => '1','dest_addr'=>'255700000001'),array('recipient_id' => '2','dest_addr'=>'255700000011')]
                    'recipients' => [array('recipient_id' => $aidi,'dest_addr'=>$nani)]
                );
                
                $Url ='https://apisms.beem.africa/v1/send';
                
                $ch = curl_init($Url);
                error_reporting(E_ALL);
                ini_set('display_errors', 1);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                curl_setopt_array($ch, array(
                    CURLOPT_POST => TRUE,
                    CURLOPT_RETURNTRANSFER => TRUE,
                    CURLOPT_HTTPHEADER => array(
                        'Authorization:Basic ' . base64_encode("$api_key:$secret_key"),
                        'Content-Type: application/json'
                    ),
                    CURLOPT_POSTFIELDS => json_encode($postData)
                ));
                
                $response = curl_exec($ch);
                
                if($response === FALSE){
                        echo $response;
                
                    die(curl_error($ch));
                }
                var_dump($response);
                
                //end sms
     var_dump($zzfe);
                $a++;
               }
               
                



        }


    $message="<div class='alert alert-success alert-dismissible fade show'>
    <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span>
    </button> <strong>Hongera!</strong>Taarifa imetumwa.</div>";
}
else{
    $message="<div class='alert alert-warning alert-dismissible fade show'>
    <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span>
    </button> <strong>Angalizo!</strong>Taarifa hazijaenda.</div>";
    
}
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>F.N.P.W.A | posti</title>

    <link href="plugins/tables/css/datatable/dataTables.bootstrap4.min.css" rel="stylesheet">

    <link href="css/style.css" rel="stylesheet">

</head>

<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
   
    <div id="main-wrapper">

  <?php 
    require("nav.php");
  ?>

        <div class="content-body">

        <div class="container-fluid">


        <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Andika Posti</h4>
                                <div class="basic-form">
                                    <form method="post">
                                    <div class="form-group">
                                  <?php echo $message; ?>

                                     </div>
                                    <div class="form-group">
                                            <input type="text" class="form-control input-default" name="who" placeholder="" value="Mtumaji - <?php echo $who;?>" disabled="disabled">
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control input-default" name="title" placeholder="kichwa cha habari" required="required">
                                        </div>
                                        <div class="form-group">
                                            <label>Aina Ya Posti:</label>
                                            <select name="cat" class="form-control" id="sel1">
                                                <option value="Matunzo">Matunzo</option>
                                                <option value="Chakula">Chakula</option>
                                                <option value="Afya">Afya</option>
                                                <option value="Tahathari">Tahathari</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Kundi La Mzazi:</label>
                                            <select name="group" class="form-control" id="sel2">
                                                <option value="Wote">Wote</option>
                                                <option value="Mwezi 0-3">Mwezi 0-3</option>
                                                <option value="Mwezi 4-7">Mwezi 4-7</option>
                                                <option value="Mwezi 8-9">Mwezi 8-9</option>
                                                <option value="Walio Zaliwa">Walio Zaliwa</option>
                                            </select>
                                        </div>
                                       
                                        <div class="form-group">
                                        <label>Ujumbe:</label>
                                            <textarea class="form-control h-150px" rows="6" name="descr" id="Ujumbe" required="required"></textarea>
                                        </div>

                                        <!-- to turn on or off the notification -->

                                        <div class="form-group">
                                        <label>Unataka kuwatumia taarifa wazazi? :</label>
                                        <span>Hapana </span>
                                        <input type="radio" name="ntf" value="no" required="required">
                                        <span>Ndio </span>
                                        <input type="radio" name="ntf" value="yes" required="required">
                                        </div>

                                        <div class="form-group">
                                        <button type="submit" name="kawaida" class="btn mb-1 btn-success">Tuma ujumbe</button>
                                        </div>
                                       
                                    </form>
                                </div>
                            </div>
                        </div>
                     </div>   

                     </div>

                 </div>
         

                 
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Posti Zilizo Tumwa</h4>
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered zero-configuration">
                                        <thead>
                                            <tr>
                                                <th>Namba</th>
                                                <th>Kichwa Cha Habari</th>
                                                <th>Ujumbe</th>
                                                <th>Aina</th>
                                                <th>Kundi</th>
                                                <th>Muda</th>
                                                <th>Muhusika</th>
                                                <th>Waliosoma</th>
                                                <th></th>
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                        <?php
                                        // SELECT `id`, `title`, `description`, `time`, `author` FROM `post` WHERE 1
                                        $re="SELECT * FROM `post`";
                                        $cfr=mysqli_query($connect,$re);
                                        $a=1;

           
                                        while ($fe=mysqli_fetch_array($cfr)) {
                                              
                                            $sss=$fe['id'];

                                            //hesabu
                                            $sre="SELECT * FROM `readlog` WHERE `postid`='$sss'";
                                            $scfr=mysqli_query($connect,$sre);
                                            $ccfr=mysqli_num_rows($scfr);

                                            echo' <tr>
                                            <td>'.$a.'</td>
                                            <td>'.$fe['title'].'</td>
                                            <td>'.$fe['description'].'</td>
                                            <td>'.$fe['categories'].'</td>
                                            <td>'.$fe['parentgroups'].'</td>
                                            <td>'.$fe['time'].'</td>
                                            <td>'.$fe['author'].'</td>
                                            <td>'.$ccfr.'</td>
                                            <td><a class="btn mb-1 btn-info" href="editpost.php?key='.$fe['id'].'">Badili</a></td>
                                            <td><a class="btn mb-1 btn-danger" href="deletepost.php?key='.$fe['id'].'">Futa</a></td>
                                        </tr>
                                           ';
                                            $a++;
                                           }
                                           
                                            ?>
                                            
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>Namba</th>
                                                <th>Kichwa Cha Habari</th>
                                                <th>Ujumbe</th>
                                                <th>Aina</th>
                                                <th>Kundi</th>
                                                <th>Muda</th>
                                                <th>Muhusika</th>
                                                <th>WAliosoma</th>
                                                <th></th>
                                                <th></th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #/ container -->
        </div>
       



        <!--**********************************
            Content body end
        ***********************************-->
        
        
       
    </div>
  
    <script src="plugins/common/common.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/settings.js"></script>
    <script src="js/gleek.js"></script>
    <script src="js/styleSwitcher.js"></script>


    <script src="plugins/tables/js/jquery.dataTables.min.js"></script>
    <script src="plugins/tables/js/datatable/dataTables.bootstrap4.min.js"></script>
    <script src="plugins/tables/js/datatable-init/datatable-basic.min.js"></script>

</body>

</html>