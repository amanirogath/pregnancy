<?php
session_start();
require("conn.php");

$i=$_GET['key'];

// INSERT INTO `admins`(`id`, `special_id`, `full_name`, `email`, `phone`, `cheo`, `password`)

$message="";

if(isset($_POST['enda'])){

    $flname=mysqli_real_escape_string($connect,trim(htmlspecialchars($_POST['flname'])));
    $em=mysqli_real_escape_string($connect,trim(htmlspecialchars($_POST['email'])));
    $p=mysqli_real_escape_string($connect,trim(htmlspecialchars($_POST['phone'])));
    $p1=mysqli_real_escape_string($connect,trim(htmlspecialchars($_POST['p1'])));
    $p2=mysqli_real_escape_string($connect,trim(htmlspecialchars($_POST['p2'])));


    if($p1==$p2){

    

    $hush=password_hash($p1,PASSWORD_DEFAULT);



    $al="UPDATE `admins` SET `full_name`='$flname',`email`='$em',`phone`='$p',`password`='$hush' WHERE `special_id`='$i'";


 $isha=mysqli_query($connect,$al);
 
 if($isha){
   header("location:leaders.php");
}
else{
    $message="<div class='alert alert-danger alert-dismissible fade show'>
    <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span>
    </button> <strong>Angalizo!</strong>Taarifa hazijaenda.</div>";
}
    }
    else{
        $message="<div class='alert alert-warning alert-dismissible fade show'>
    <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span>
    </button> <strong>Angalizo!</strong>Nywila hazifanani.</div>";
    }

}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>F.N.P.W.A | editstaff</title>

    <link href="plugins/tables/css/datatable/dataTables.bootstrap4.min.css" rel="stylesheet">

    <link href="css/style.css" rel="stylesheet">

</head>

<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
   
    <div id="main-wrapper">

  <?php 
    require("nav.php");
  ?>

        <div class="content-body">

          
        <div class="container-fluid">


<div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Jaza Taarifa za kiongozi</h4>
                        <div class="basic-form">
                            <form method="post">
                            <div class="form-group">
                          <?php echo $message; ?>

                             </div>
<!-- // INSERT INTO `admins`(`id`, `special_id`, `full_name`, `email`, `phone`, `cheo`, `password`) -->

<?php
                                    $re="SELECT * FROM `admins` WHERE `special_id`='$i'";
                                        $cfr=mysqli_query($connect,$re);
                                        $a=1;

                                   
                                      $fe=mysqli_fetch_array($cfr);

                                     ?>

                            <div class="form-group">
                                    <input type="text" class="form-control input-default" name="flname" placeholder="majina kamili" value="<?php echo $fe['full_name'];?>" required="required">
                                </div>

                                <div class="form-group">
                                    <input type="email" class="form-control input-default" name="email" placeholder="Barua pepe" value="<?php echo $fe['email'];?>" required="required">
                                </div>

                                <div class="form-group">
                                    <input type="text" class="form-control input-default" name="phone" placeholder="namba ya simu" value="<?php echo $fe['phone'];?>" required="required">
                                </div>
                                
                                <div class="form-group">
                                    <input type="password" class="form-control input-default" name="p1" placeholder="nywila" required="required">
                                </div>

                                <div class="form-group">
                                    <input type="password" class="form-control input-default" name="p2" placeholder="rudia nywila" required="required">
                                </div>
                                
                                <div class="form-group">
                                <button type="submit" name="enda" class="btn mb-1 btn-success">Tuma Taarifa</button>
                                </div>
                               
                            </form>
                        </div>
                    </div>
                </div>
             </div>   

             </div>

         </div>
        
      
        <!--**********************************
            Content body end
        ***********************************-->
        
        
       
    </div>
  
    <script src="plugins/common/common.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/settings.js"></script>
    <script src="js/gleek.js"></script>
    <script src="js/styleSwitcher.js"></script>


  
</body>

</html>