<?php
error_reporting(E_ALL); ini_set('display_errors', 'Off');
define('FPDF_FONTPATH','font/');
require("fpdf.php");
class PDF extends FPDF
{
//Page header
function Header()
{
    //Logo
   // $this->Image('logo/logo.png',5,5,35,35);
	// $this->Image('logo/logo.png',255,5,35,35);
    //Arial bold 15
    $this->SetFont('Arial','B',6);
    //Move to the right
    $this->Cell(80);
   
    //Line break
    $this->Ln(20);
}
//Page footer
function Footer()
{
    //Position at 1.5 cm from bottom
    $this->SetY(-15);
    //Arial italic 8
  $this->SetFont('Arial','I',10);
    //Page number
    $this->Cell(0,10,'Page '.$this->PageNo().' / {nb}',0,0,'C');
}
}
$y=3;
$x=5;
$max=175;
$newy=8;
$org="ARUSHA TECHNICAL COLLEGE";
$add="296 ARUSHA";
$pdf=new PDF();
$pdf->AliasNbPages();
$pdf->AddPage('L','A4');
$x3=1;
	$pdf->SetFont('Arial','B',10);
	$pdf->SetY($y);
	$pdf->SetX($x3);
	$pdf->MultiCell(295,5,$org,0,'C');
	$y=$y+7;
	$pdf->SetFont('Arial','I',10);
	$pdf->SetY($y);
	$pdf->SetX($x3);
	$pdf->MultiCell(295,5,$add,0,'C');
	$y=$y+7;

	$pdf->SetFont('Arial','B',10);
	$pdf->SetY($y);
	$pdf->SetX($x3);
	$pdf->MultiCell(295,5,'NEAR TRIPLE A',0,'C');
	$y=$y+5;
	
	$pdf->SetFillColor(204,2204,204);
	$y=31;
	$x=3;
	$pdf->SetFont('Arial','B',10);
	$pdf->SetY($y);
	$pdf->SetX($x3);
	$pdf->Cell(295,5,$dept.' DEPARTMENT',0,0,'C');
	$y=$y+7;

	$pdf->SetY($y);
	$pdf->SetX($x3);
	$pdf->Cell(295,5,$p,0,0,'C');
	$y=$y+7;
	 $yr=base64_decode($_GET['yr']);
	$pdf->SetY($y);
	$pdf->SetX($x3);
	$pdf->Cell(295,5,$nta." SEMESTER ".$semz.' ,STUDENTS` PERSONAL PARTICULARS - '.$yr,0,0,'C');
	$y=$y+7;

$pdf->SetFillColor(215,255,255);
//FIRST column
$x=10;
$pdf->SetFont('Arial','',10);
$pdf->SetY($y);
$pdf->SetX($x);
$pdf->Cell(10,7,'Sno',1,0,'L','1');
$x=$x+10;

$pdf->SetY($y);
$pdf->SetX($x);
$pdf->Cell(48,7,'Full Name',1,0,'L');
$x=$x+48;
$pdf->SetY($y);
$pdf->SetX($x);
$pdf->Cell(40,7,'Form Four Index Number',1,0,'C','1');


$x=$x+40;
$pdf->SetY($y);
$pdf->SetX($x);
$pdf->Cell(18,7,'Gender',1,0,'C','1');

$x=$x+18;
$pdf->SetY($y);
$pdf->SetX($x);
$pdf->Cell(26,7,'Date of Birth',1,0,'C','1');

$x=$x+26;
$pdf->SetY($y);
$pdf->SetX($x);
$pdf->Cell(50,7,'Email',1,1,'C','1');

$x=$x+50;
$pdf->SetY($y);
$pdf->SetX($x);
$pdf->Cell(30,7,'Mobile Number',1,1,'C','1');	
$x=$x+30;
$pdf->SetY($y);
$pdf->SetX($x);
$pdf->Cell(35,7,'Admission Number',1,1,'C','1');
$x=$x+35;
$pdf->SetY($y);
$pdf->SetX($x);
$pdf->Cell(25,7,'Signature',1,1,'C','1');		
$height=3;

$x=10;
$n=0;
$sql="SELECT * FROM students WHERE course='$coz' and semister='$sem' and academicyear='$yr' order by fname";
$result=mysql_query($sql);
$k=1;
while($rows=mysql_fetch_array($result))
{
//add new page
if ($y>=$max) 
{ 
$pdf->AddPage('L','A4'); 
$x=5;
$y=$newy;
$pdf->SetFont('Arial','B',12);

$x3=1;
	$pdf->SetFont('Arial','B',10);
	$pdf->SetY($y);
	$pdf->SetX($x3);
	$pdf->MultiCell(295,5,$org,0,'C');
	$y=$y+7;

	$pdf->SetFont('Arial','B',10);
	$pdf->SetY($y);
	$pdf->SetX($x3);
	$pdf->MultiCell(295,5,$add,0,'C');
	$y=$y+7;

	$pdf->SetFont('Arial','B',10);
	$pdf->SetY($y);
	$pdf->SetX($x3);
	$pdf->MultiCell(295,5,$loc,0,'C');
	$y=$y+5;
	
	$pdf->SetFillColor(204,2204,204);
	$y=31;
	$x=3;
	$prog="SELECT * FROM programs where abbr='$coz'";
	$run=mysql_query($prog);
	$show=mysql_fetch_array($run);
	$p=str_replace("ORDINARY DIPLOMA",$coz_nm,$show['prog']);
if($sem>='7'&&$sem<='12')
{
$p=str_replace("BACHELOR DEGREE",$coz_nm,$show['prog']);
}
	$level=$show['level'];

	$dept=strtoupper($show['dept']);
	$pdf->SetFont('Arial','B',10);
	$pdf->SetY($y);
	$pdf->SetX($x3);
	$pdf->Cell(295,5,$dept.' DEPARTMENT',0,0,'C');
	$y=$y+7;

	$pdf->SetY($y);
	$pdf->SetX($x3);
	$pdf->Cell(295,5,$p,0,0,'C');
	$y=$y+7;
	 $yr=base64_decode($_GET['yr']);
	$pdf->SetY($y);
	$pdf->SetX($x3);
	$pdf->Cell(295,5,$nta." SEMESTER ".$semz.' ,STUDENTS` PERSONAL PARTICULARS - '.$yr,0,0,'C');
	$y=$y+7;

$pdf->SetFillColor(215,255,0);
//FIRST column
$x=10;
$pdf->SetFont('Arial','',10);
$pdf->SetY($y);
$pdf->SetX($x);
$pdf->Cell(10,7,'Sno',1,0,'L','1');
$x=$x+10;

$pdf->SetY($y);
$pdf->SetX($x);
$pdf->Cell(48,7,'Full Name',1,0,'L','1');
$x=$x+48;
$pdf->SetY($y);
$pdf->SetX($x);
$pdf->Cell(40,7,'Form Four Index Number',1,0,'C','1');


$x=$x+40;
$pdf->SetY($y);
$pdf->SetX($x);
$pdf->Cell(18,7,'Gender',1,0,'C','1');

$x=$x+18;
$pdf->SetY($y);
$pdf->SetX($x);
$pdf->Cell(26,7,'Date of Birth',1,0,'C','1');

$x=$x+26;
$pdf->SetY($y);
$pdf->SetX($x);
$pdf->Cell(50,7,'Email',1,1,'C','1');

$x=$x+50;
$pdf->SetY($y);
$pdf->SetX($x);
$pdf->Cell(30,7,'Mobile Number',1,1,'C','1');	
$x=$x+30;
$pdf->SetY($y);
$pdf->SetX($x);
$pdf->Cell(35,7,'Admission Number',1,1,'C','1');
$x=$x+35;
$pdf->SetY($y);
$pdf->SetX($x);
$pdf->Cell(25,7,'Signature',1,1,'C','1');		
}
$pdf->SetFont('Arial','',8);
$i=$k;
$stid=$rows['id'];
$fname=$rows['fname'];
$sname=$rows['sname'];
$mname=$rows['mname'];
$stname=$fname." ".$mname." ".$sname;
$stname=strtolower($stname);
$items[$i]=$rows['fname'];
$stname=ucwords(ucfirst($stname));
$y=$y+7;
$x=10;
$pdf->SetY($y);
	$pdf->SetX($x);
	$pdf->Cell(10,7,$k,1,0,'C');
	$x=$x+10;
	$lines =explode("<br/>", wordwrap($items[$i], '20', "<br />\n"));
	//Data
		$pdf->SetFont('Arial','',10);
		$pdf->SetY($y);
		$pdf->SetX($x);
		$pdf->Cell(48,7,$stname,1,1,'L');
		$y=$y+0;
		
//search specific std
$sql="SELECT * FROM students WHERE id='$stid'";
$result2=mysql_query($sql);
$rows2=mysql_fetch_array($result2);
$fyear=$rows2['fyear'];
$findex=$rows2['formfourindex'];
$f4=$findex."-".$fyear;
$sem=$rows2['semister'];
$lev=$rows2['level'];
$status=$rows2['status'];
$sex=$rows2['gender'];
$year=$rows2['year'];
$dob=$rows2['dob'];
$email=$rows2['email'];
$mobile=$rows2['mobile'];
$regno=$rows2['regno'];
//echo $i."<br>";
//echo $nm."<br>";
//die();

$x=$x+48;
$pdf->SetY($y);
$pdf->SetX($x);
$pdf->Cell(40,7,$f4,1,0,'L');
$y=$y+0;

$x=$x+40;
$pdf->SetY($y);
$pdf->SetX($x);
$pdf->Cell(18,7,$sex,1,0,'L');

$x=$x+18;

$pdf->SetY($y);
$pdf->SetX($x);
$pdf->Cell(26,7,$dob,1,0,'L');


$x=$x+26;
$pdf->SetY($y);
$pdf->SetX($x);
$pdf->Cell(50,7,$email,1,1,'L');

$x=$x+50;
$pdf->SetY($y);
$pdf->SetX($x);
$pdf->Cell(30,7,$mobile,1,1,'L');	
$x=$x+30;
$pdf->SetY($y);
$pdf->SetX($x);
$pdf->Cell(35,7,$regno,1,1,'L');	
$x=$x+35;
$pdf->SetY($y);
$pdf->SetX($x);
$pdf->Cell(25,7,'',1,1,'L');	
$k++;	
}
$pdf->SetY($y);
$pdf->SetX($x);
$tablez="List-of-students".'.pdf';
$pdf->Output($tablez, 'I'); 
?>


