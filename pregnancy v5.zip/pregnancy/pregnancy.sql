-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 18, 2022 at 02:15 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.4.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pregnancy`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `special_id` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `cheo` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `special_id`, `full_name`, `email`, `phone`, `cheo`, `password`) VALUES
(2, 'ea49gHb8F1ij507JA6ECDG3cBf2dIh', 'amani mworia', 'amarogath94@gmail.com', '0743000000', 'admin', '$2y$10$kJYV1EiRrLNBWhRGl2BRduBrnC.lizDvYs6jDKs1oHatifOVwaM5u'),
(3, 'cF1CAE8IJhaG97fD624dBbgijH053e', 'asdfv', 'amarogasdfgth94@gmail.com', '123456', 'doctor', '$2y$10$TMHEueszHR1Xz1R0cwlt3usdLZ8vM9JFp3whdKL3f.G8zkK4KyjN6'),
(4, 'I71FEbD8dA395iHecC6Jaj4gBh20Gf', 'kjjdjkdnkj', '', '222hh3322', 'admin', '$2y$10$pTB5p6wjqUqpNZ5W9EoiveNqh.gfWIJNseObBSPx2gbc1I9K6eXIa'),
(5, '3hAbI7Ea5ig8FcJ12HdBf6e4DGj90C', 'amani amani', 'amanirogath@gmail.com', '0743722720', 'doctor', '$2y$10$yxd0/nzNHaQFaRqt6Qr1vuf.OV06uX5Oq6udP5KS4ew.m8qCAspUG');

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE `answers` (
  `id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `answer` varchar(255) NOT NULL,
  `time` varchar(40) NOT NULL,
  `person` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `answers`
--

INSERT INTO `answers` (`id`, `question_id`, `answer`, `time`, `person`) VALUES
(1, 2, 'akakakakmndol odjssf jksdfkjj', '22-05-2022 08:29:12am', 'amani rogath'),
(2, 3, 'iouyuhgyu', '22-05-2022 08:29:20am', 'amani rogath'),
(3, 1, 'asdfvb', '22-05-2022 08:29:25am', 'amani rogath'),
(4, 2, 'aaaaaaaaaaaaaaaaapppppppppppppp', '22-05-2022 08:53:20am', 'amani rogath');

-- --------------------------------------------------------

--
-- Table structure for table `center`
--

CREATE TABLE `center` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `region` varchar(200) NOT NULL,
  `district` varchar(200) NOT NULL,
  `ward` varchar(200) NOT NULL,
  `street` varchar(200) NOT NULL,
  `address` varchar(255) NOT NULL,
  `opentime` varchar(200) NOT NULL,
  `emergency` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `center`
--

INSERT INTO `center` (`id`, `name`, `region`, `district`, `ward`, `street`, `address`, `opentime`, `emergency`) VALUES
(1, '', 'arusha@d.d', 'arusha', 'oltrumet', 'ilkiushin@d.d', '', 'masaa 24', 'phone@d.d'),
(2, '32 st', 'arusha', 'arusha', 'ilkiushin', 'ngusero', 'Mkoa-arusha,Wilaya-arusha,Kata-ilkiushin,Mtaa/Kijiji-ngusero .', 'saa12 mpaka saa11 jioni', '02929292929'),
(3, 'afya tec', 'arusha', 'arusha', 'olorien', 'tejoo', 'Mkoa-arusha,Wilaya-arusha,Kata-olorien,Mtaa/Kijiji-tejoo .', 'masaa 24', '07666666666');

-- --------------------------------------------------------

--
-- Table structure for table `checker`
--

CREATE TABLE `checker` (
  `id` int(11) NOT NULL,
  `datez` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `checker`
--

INSERT INTO `checker` (`id`, `datez`) VALUES
(1, '2022-07-18');

-- --------------------------------------------------------

--
-- Table structure for table `children`
--

CREATE TABLE `children` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `birthdate` varchar(50) NOT NULL,
  `parentid` varchar(255) NOT NULL,
  `placeofbirth` varchar(255) NOT NULL,
  `gender` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `children`
--

INSERT INTO `children` (`id`, `fullname`, `birthdate`, `parentid`, `placeofbirth`, `gender`) VALUES
(1, 'asdfk skkskk', '2022-05-12', 'veronica@gmail.com', 'arusha', 'female');

-- --------------------------------------------------------

--
-- Table structure for table `inquiries`
--

CREATE TABLE `inquiries` (
  `id` int(11) NOT NULL,
  `person` varchar(100) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `time` varchar(40) NOT NULL,
  `expire` varchar(50) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `inquiries`
--

INSERT INTO `inquiries` (`id`, `person`, `title`, `description`, `time`, `expire`, `status`) VALUES
(1, 'all', 'aaaa', 'ssssss\r\n', '22-05-2022 02:30:53am', '', 'Limejibiwa'),
(2, 'all', 'sdfvgbnjhgfd', 'edhytjtydjrnt grhrthr45thrththrt', '22-05-2022 02:48:46am', '', 'Limejibiwa'),
(3, 'all', 'zSCvzSB BX', 'SDVSDFBDFBNDFG\r\nXC X', '22-05-2022 02:49:39am', '', 'Limejibiwa'),
(4, 'all', 'sbn', 'sdcfvbnm', '19-06-2022 10:46:49pm', '', 'Halijajibiwa'),
(5, 'all', 'ASDFVGBN', 'sdfvb', '19-06-2022 11:25:03pm', '22-06-2022', 'Halijajibiwa'),
(6, 'all', 'asdfvbn', 'sdcfvbn', '19-06-2022 11:35:40pm', '18-06-2022', 'Halijajibiwa'),
(7, 'all', 'asdfgbhnm', 'asdfgbn', '19-06-2022 11:39:27pm', '15-06-2022', 'Limejibiwa'),
(8, 'all', 'zxcvbsdcfvb', 'bhbj vjksdvbvk sjvk\r\n', '19-06-2022 11:39:39pm', '15-06-2022', 'Halijajibiwa'),
(9, 'all', 'sdfg', 'qwerghjk', '19-06-2022 11:46:03pm', '12-06-2022', 'Halijajibiwa'),
(10, 'all', 'lkjhgfdsdfgh', 'swdfdghgbhmn,m ', '19-06-2022 11:46:15pm', '12-06-2022', 'Limejibiwa'),
(11, 'all', 'asdfv', 'zxcbv', '19-06-2022 11:51:39pm', '14-06-2022', 'Halijajibiwa'),
(12, 'amarogasdfgth94@gmail.com', 'qsdfgbn', 'mnfd', '19-06-2022 11:51:46pm', '14-06-2022', 'Limejibiwa'),
(13, 'all', 'vbsdf', 'ADFGHJMJGFD\r\n\r\n', '19-06-2022 11:53:30pm', '10-06-2022', 'Halijajibiwa'),
(14, 'all', 'ASDFGBHNHGD', 'ASDFGH', '19-06-2022 11:53:39pm', '22-04-2022', 'Halijajibiwa'),
(15, 'all', 'ZDFVBNqwedf', 'sdfghjhgf\r\n', '19-06-2022 11:53:48pm', '22-06-2010', 'Halijajibiwa'),
(16, 'all', 'sc', 'sdc ', '20-06-2022 12:04:30am', '23-12-2007', 'Halijajibiwa');

-- --------------------------------------------------------

--
-- Table structure for table `log`
--

CREATE TABLE `log` (
  `id` int(11) NOT NULL,
  `user_id` varchar(200) NOT NULL,
  `datetime` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  `browser` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `log`
--

INSERT INTO `log` (`id`, `user_id`, `datetime`, `status`, `browser`) VALUES
(1, '69J8d3HgjahcFIiC4beEfDGA1B5207', '15-04-2022 06:08:56am', 'login', 'Chrome'),
(2, '69J8d3HgjahcFIiC4beEfDGA1B5207', '15-04-2022', 'logout', 'Chrome'),
(3, '69J8d3HgjahcFIiC4beEfDGA1B5207', '15-04-2022 06:11:51am', 'login', 'Chrome'),
(4, '69J8d3HgjahcFIiC4beEfDGA1B5207', '15-04-2022', 'logout', 'Chrome'),
(5, '69J8d3HgjahcFIiC4beEfDGA1B5207', '15-04-2022 06:16:46am', 'login', 'Chrome'),
(6, '69J8d3HgjahcFIiC4beEfDGA1B5207', '15-04-2022 06:19:48am', 'logout', 'Chrome'),
(7, '0b5iE897CgHj24ah3D61JFdIBeGAfc', '15-05-2022 03:37:07pm', 'login', 'Chrome'),
(8, '0b5iE897CgHj24ah3D61JFdIBeGAfc', '18-05-2022 08:30:16am', 'login', 'Chrome'),
(9, '0b5iE897CgHj24ah3D61JFdIBeGAfc', '18-05-2022 02:52:41pm', 'logout', 'Chrome'),
(10, '0b5iE897CgHj24ah3D61JFdIBeGAfc', '18-05-2022 03:20:21pm', 'login', 'Chrome'),
(11, '0b5iE897CgHj24ah3D61JFdIBeGAfc', '18-05-2022 03:32:28pm', 'login', 'Chrome'),
(12, '0b5iE897CgHj24ah3D61JFdIBeGAfc', '18-05-2022 03:53:44pm', 'login', 'Chrome'),
(13, '0b5iE897CgHj24ah3D61JFdIBeGAfc', '18-05-2022 03:54:25pm', 'login', 'Chrome'),
(14, '0b5iE897CgHj24ah3D61JFdIBeGAfc', '18-05-2022 11:17:13pm', 'login', 'Chrome'),
(15, '0b5iE897CgHj24ah3D61JFdIBeGAfc', '18-05-2022 11:17:25pm', 'login', 'Chrome'),
(16, '0b5iE897CgHj24ah3D61JFdIBeGAfc', '21-05-2022 07:26:01pm', 'login', 'Chrome'),
(17, '0b5iE897CgHj24ah3D61JFdIBeGAfc', '21-05-2022 11:27:02pm', 'logout', 'Chrome'),
(18, '', '21-05-2022 11:58:02pm', 'logout', 'Chrome'),
(19, '', '22-05-2022 12:02:17am', 'logout', 'Chrome'),
(20, 'Fa2GIf69EHA4D10hgJBcdCeb8i537j', '22-05-2022 12:17:25am', 'login', 'Chrome'),
(21, 'Fa2GIf69EHA4D10hgJBcdCeb8i537j', '22-05-2022 12:17:32am', 'logout', 'Chrome'),
(22, 'I6eC34A0Jg81F79ihGa2bdcBjDfH5E', '22-05-2022 12:31:45am', 'login', 'Chrome'),
(23, 'I6eC34A0Jg81F79ihGa2bdcBjDfH5E', '22-05-2022 12:32:00am', 'logout', 'Chrome'),
(24, 'I6eC34A0Jg81F79ihGa2bdcBjDfH5E', '22-05-2022 12:33:26am', 'login', 'Chrome'),
(25, 'I6eC34A0Jg81F79ihGa2bdcBjDfH5E', '22-05-2022 12:33:36am', 'logout', 'Chrome'),
(26, 'I6eC34A0Jg81F79ihGa2bdcBjDfH5E', '22-05-2022 12:36:51am', 'login', 'Chrome'),
(27, 'I6eC34A0Jg81F79ihGa2bdcBjDfH5E', '22-05-2022 01:24:52am', 'logout', 'Chrome'),
(28, 'I6eC34A0Jg81F79ihGa2bdcBjDfH5E', '22-05-2022 01:25:42am', 'login', 'Chrome'),
(29, 'ea49gHb8F1ij507JA6ECDG3cBf2dIh', '22-05-2022 01:27:47am', 'login', 'Chrome'),
(30, 'I6eC34A0Jg81F79ihGa2bdcBjDfH5E', '22-05-2022 01:32:45am', 'login', 'Microsoft Edge'),
(31, '', '22-05-2022 09:05:31am', 'logout', 'Microsoft Edge'),
(32, 'I6eC34A0Jg81F79ihGa2bdcBjDfH5E', '22-05-2022 09:45:09am', 'login', 'Microsoft Edge'),
(33, 'norah@gmail.com', '22-05-2022 09:45:17am', 'logout', 'Microsoft Edge'),
(34, 'I6eC34A0Jg81F79ihGa2bdcBjDfH5E', '22-05-2022 09:45:27am', 'login', 'Microsoft Edge'),
(35, '', '22-05-2022 09:49:08am', 'logout', 'Chrome'),
(36, 'GE3CJ82Bb5efcg67HiDIh4j01a9AFd', '22-05-2022 09:50:10am', 'login', 'Chrome'),
(37, 'veronica@gmail.com', '22-05-2022 09:50:43am', 'logout', 'Chrome'),
(38, 'ea49gHb8F1ij507JA6ECDG3cBf2dIh', '22-05-2022 09:51:10am', 'login', 'Chrome'),
(39, 'norah@gmail.com', '22-05-2022 10:11:47am', 'logout', 'Microsoft Edge'),
(40, 'GE3CJ82Bb5efcg67HiDIh4j01a9AFd', '22-05-2022 10:12:02am', 'login', 'Microsoft Edge'),
(41, 'amarogath94@gmail.com', '22-05-2022 11:10:38am', 'logout', 'Chrome'),
(42, 'ea49gHb8F1ij507JA6ECDG3cBf2dIh', '22-05-2022 11:13:22am', 'login', 'Chrome'),
(43, 'veronica@gmail.com', '22-05-2022 11:13:34am', 'logout', 'Microsoft Edge'),
(44, 'GE3CJ82Bb5efcg67HiDIh4j01a9AFd', '22-05-2022 11:24:15am', 'login', 'Microsoft Edge'),
(45, 'amarogath94@gmail.com', '22-05-2022 12:23:34pm', 'logout', 'Chrome'),
(46, 'I6eC34A0Jg81F79ihGa2bdcBjDfH5E', '22-05-2022 12:23:39pm', 'login', 'Chrome'),
(47, 'norah@gmail.com', '22-05-2022 12:23:52pm', 'logout', 'Chrome'),
(48, 'ea49gHb8F1ij507JA6ECDG3cBf2dIh', '22-05-2022 12:23:58pm', 'login', 'Chrome'),
(49, 'veronica@gmail.com', '22-05-2022 01:20:35pm', 'logout', 'Microsoft Edge'),
(50, '24GdDheABa60Ii9J8f1Fc5bCg7j3EH', '22-05-2022 01:21:02pm', 'login', 'Microsoft Edge'),
(51, 'amarogath94@gmail.com', '22-05-2022 03:49:38pm', 'logout', 'Chrome'),
(52, 'ea49gHb8F1ij507JA6ECDG3cBf2dIh', '22-05-2022 03:49:52pm', 'login', 'Chrome'),
(53, 'veronica@gmail.com', '22-05-2022 03:52:01pm', 'logout', 'Microsoft Edge'),
(54, '24GdDheABa60Ii9J8f1Fc5bCg7j3EH', '22-05-2022 03:52:14pm', 'login', 'Microsoft Edge'),
(55, 'amarogath94@gmail.com', '22-05-2022 04:24:34pm', 'logout', 'Chrome'),
(56, 'veronica@gmail.com', '22-05-2022 04:24:48pm', 'logout', 'Microsoft Edge'),
(57, '24GdDheABa60Ii9J8f1Fc5bCg7j3EH', '22-05-2022 04:26:11pm', 'login', 'Microsoft Edge'),
(58, 'ea49gHb8F1ij507JA6ECDG3cBf2dIh', '22-05-2022 04:28:16pm', 'login', 'Chrome'),
(59, 'ea49gHb8F1ij507JA6ECDG3cBf2dIh', '18-06-2022 05:29:56pm', 'login', 'Chrome'),
(60, 'amarogath94@gmail.com', '18-06-2022 05:32:14pm', 'logout', 'Chrome'),
(61, '24GdDheABa60Ii9J8f1Fc5bCg7j3EH', '18-06-2022 05:33:11pm', 'login', 'Chrome'),
(62, 'veronica@gmail.com', '18-06-2022 05:48:54pm', 'logout', 'Chrome'),
(63, 'ea49gHb8F1ij507JA6ECDG3cBf2dIh', '18-06-2022 05:49:18pm', 'login', 'Chrome'),
(64, 'amarogath94@gmail.com', '18-06-2022 05:49:42pm', 'logout', 'Chrome'),
(65, 'ea49gHb8F1ij507JA6ECDG3cBf2dIh', '19-06-2022 08:40:21pm', 'login', 'Chrome'),
(66, 'ea49gHb8F1ij507JA6ECDG3cBf2dIh', '19-06-2022 08:40:22pm', 'login', 'Chrome'),
(67, 'amarogath94@gmail.com', '19-06-2022 09:16:32pm', 'logout', 'Chrome'),
(68, '24GdDheABa60Ii9J8f1Fc5bCg7j3EH', '19-06-2022 09:16:44pm', 'login', 'Chrome'),
(69, 'veronica@gmail.com', '19-06-2022 09:19:22pm', 'logout', 'Chrome'),
(70, '24GdDheABa60Ii9J8f1Fc5bCg7j3EH', '19-06-2022 09:25:52pm', 'login', 'Chrome'),
(71, 'veronica@gmail.com', '19-06-2022 09:25:56pm', 'logout', 'Chrome'),
(72, '24GdDheABa60Ii9J8f1Fc5bCg7j3EH', '19-06-2022 09:27:56pm', 'login', 'Chrome'),
(73, 'veronica@gmail.com', '19-06-2022 09:28:03pm', 'logout', 'Chrome'),
(74, 'ea49gHb8F1ij507JA6ECDG3cBf2dIh', '19-06-2022 09:34:24pm', 'login', 'Chrome'),
(75, 'amarogath94@gmail.com', '19-06-2022 09:57:32pm', 'logout', 'Chrome'),
(76, 'ea49gHb8F1ij507JA6ECDG3cBf2dIh', '19-06-2022 09:57:36pm', 'login', 'Chrome'),
(77, 'amarogath94@gmail.com', '19-06-2022 09:59:30pm', 'logout', 'Chrome'),
(78, '3hAbI7Ea5ig8FcJ12HdBf6e4DGj90C', '19-06-2022 09:59:49pm', 'login', 'Chrome'),
(79, 'amanirogath@gmail.com', '19-06-2022 10:16:01pm', 'logout', 'Chrome'),
(80, 'ea49gHb8F1ij507JA6ECDG3cBf2dIh', '19-06-2022 10:16:07pm', 'login', 'Chrome'),
(81, 'amarogath94@gmail.com', '19-06-2022 10:16:11pm', 'logout', 'Chrome'),
(82, '3hAbI7Ea5ig8FcJ12HdBf6e4DGj90C', '19-06-2022 10:16:29pm', 'login', 'Chrome'),
(83, 'amanirogath@gmail.com', '19-06-2022 10:17:45pm', 'logout', 'Chrome'),
(84, 'ea49gHb8F1ij507JA6ECDG3cBf2dIh', '19-06-2022 10:17:50pm', 'login', 'Chrome'),
(85, 'amarogath94@gmail.com', '19-06-2022 10:17:55pm', 'logout', 'Chrome'),
(86, '3hAbI7Ea5ig8FcJ12HdBf6e4DGj90C', '19-06-2022 10:18:30pm', 'login', 'Chrome'),
(87, 'amanirogath@gmail.com', '19-06-2022 10:21:22pm', 'logout', 'Chrome'),
(88, '24GdDheABa60Ii9J8f1Fc5bCg7j3EH', '19-06-2022 10:21:32pm', 'login', 'Chrome'),
(89, 'veronica@gmail.com', '19-06-2022 10:23:09pm', 'logout', 'Chrome'),
(90, 'ea49gHb8F1ij507JA6ECDG3cBf2dIh', '19-06-2022 10:23:19pm', 'login', 'Chrome'),
(91, 'amarogath94@gmail.com', '19-06-2022 10:25:40pm', 'logout', 'Chrome'),
(92, '24GdDheABa60Ii9J8f1Fc5bCg7j3EH', '19-06-2022 10:26:13pm', 'login', 'Chrome'),
(93, 'veronica@gmail.com', '19-06-2022 10:48:22pm', 'logout', 'Chrome'),
(94, '3hAbI7Ea5ig8FcJ12HdBf6e4DGj90C', '19-06-2022 10:48:51pm', 'login', 'Chrome'),
(95, 'amanirogath@gmail.com', '19-06-2022 11:24:18pm', 'logout', 'Chrome'),
(96, '24GdDheABa60Ii9J8f1Fc5bCg7j3EH', '19-06-2022 11:24:31pm', 'login', 'Chrome'),
(97, 'veronica@gmail.com', '19-06-2022 11:25:24pm', 'logout', 'Chrome'),
(98, 'ea49gHb8F1ij507JA6ECDG3cBf2dIh', '19-06-2022 11:25:33pm', 'login', 'Chrome'),
(99, 'amarogath94@gmail.com', '19-06-2022 11:26:08pm', 'logout', 'Chrome'),
(100, '3hAbI7Ea5ig8FcJ12HdBf6e4DGj90C', '19-06-2022 11:26:39pm', 'login', 'Chrome'),
(101, 'amanirogath@gmail.com', '19-06-2022 11:35:19pm', 'logout', 'Chrome'),
(102, '24GdDheABa60Ii9J8f1Fc5bCg7j3EH', '19-06-2022 11:35:30pm', 'login', 'Chrome'),
(103, 'veronica@gmail.com', '19-06-2022 11:36:03pm', 'logout', 'Chrome'),
(104, '3hAbI7Ea5ig8FcJ12HdBf6e4DGj90C', '19-06-2022 11:36:13pm', 'login', 'Chrome'),
(105, 'amanirogath@gmail.com', '19-06-2022 11:39:02pm', 'logout', 'Chrome'),
(106, '24GdDheABa60Ii9J8f1Fc5bCg7j3EH', '19-06-2022 11:39:14pm', 'login', 'Chrome'),
(107, 'veronica@gmail.com', '19-06-2022 11:39:43pm', 'logout', 'Chrome'),
(108, '3hAbI7Ea5ig8FcJ12HdBf6e4DGj90C', '19-06-2022 11:39:50pm', 'login', 'Chrome'),
(109, 'amanirogath@gmail.com', '19-06-2022 11:43:52pm', 'logout', 'Chrome'),
(110, '24GdDheABa60Ii9J8f1Fc5bCg7j3EH', '19-06-2022 11:44:16pm', 'login', 'Chrome'),
(111, 'veronica@gmail.com', '19-06-2022 11:46:59pm', 'logout', 'Chrome'),
(112, '3hAbI7Ea5ig8FcJ12HdBf6e4DGj90C', '19-06-2022 11:47:07pm', 'login', 'Chrome'),
(113, 'amanirogath@gmail.com', '19-06-2022 11:51:19pm', 'logout', 'Chrome'),
(114, '24GdDheABa60Ii9J8f1Fc5bCg7j3EH', '19-06-2022 11:51:29pm', 'login', 'Chrome'),
(115, 'veronica@gmail.com', '19-06-2022 11:51:49pm', 'logout', 'Chrome'),
(116, '3hAbI7Ea5ig8FcJ12HdBf6e4DGj90C', '19-06-2022 11:51:55pm', 'login', 'Chrome'),
(117, 'amanirogath@gmail.com', '19-06-2022 11:53:05pm', 'logout', 'Chrome'),
(118, '24GdDheABa60Ii9J8f1Fc5bCg7j3EH', '19-06-2022 11:53:17pm', 'login', 'Chrome'),
(119, 'veronica@gmail.com', '19-06-2022 11:54:13pm', 'logout', 'Chrome'),
(120, '3hAbI7Ea5ig8FcJ12HdBf6e4DGj90C', '19-06-2022 11:55:04pm', 'login', 'Chrome'),
(121, 'amanirogath@gmail.com', '20-06-2022 12:03:54am', 'logout', 'Chrome'),
(122, '24GdDheABa60Ii9J8f1Fc5bCg7j3EH', '20-06-2022 12:04:11am', 'login', 'Chrome'),
(123, 'veronica@gmail.com', '20-06-2022 12:05:02am', 'logout', 'Chrome'),
(124, '3hAbI7Ea5ig8FcJ12HdBf6e4DGj90C', '20-06-2022 12:05:10am', 'login', 'Chrome'),
(125, '24GdDheABa60Ii9J8f1Fc5bCg7j3EH', '01-07-2022 09:21:47am', 'login', 'Chrome'),
(126, 'veronica@gmail.com', '01-07-2022 09:36:15am', 'logout', 'Chrome'),
(127, '24GdDheABa60Ii9J8f1Fc5bCg7j3EH', '01-07-2022 09:36:56am', 'login', 'Chrome'),
(128, '24GdDheABa60Ii9J8f1Fc5bCg7j3EH', '01-07-2022 09:40:00am', 'login', 'Chrome'),
(129, 'veronica@gmail.com', '01-07-2022 09:46:10am', 'logout', 'Chrome'),
(130, '24GdDheABa60Ii9J8f1Fc5bCg7j3EH', '01-07-2022 09:56:05am', 'login', 'Chrome'),
(131, '24GdDheABa60Ii9J8f1Fc5bCg7j3EH', '01-07-2022 10:09:47am', 'login', 'Chrome'),
(132, '24GdDheABa60Ii9J8f1Fc5bCg7j3EH', '01-07-2022 10:12:33am', 'login', 'Chrome'),
(133, 'veronica@gmail.com', '01-07-2022 10:53:44am', 'logout', 'Chrome'),
(134, '24GdDheABa60Ii9J8f1Fc5bCg7j3EH', '17-07-2022 10:24:03pm', 'login', 'Chrome'),
(135, 'veronica@gmail.com', '17-07-2022 10:24:44pm', 'logout', 'Chrome'),
(136, '3hAbI7Ea5ig8FcJ12HdBf6e4DGj90C', '17-07-2022 10:24:57pm', 'login', 'Chrome'),
(137, 'amanirogath@gmail.com', '18-07-2022 03:38:42am', 'logout', 'Chrome'),
(138, '3hAbI7Ea5ig8FcJ12HdBf6e4DGj90C', '18-07-2022 03:40:01am', 'login', 'Chrome'),
(139, 'amanirogath@gmail.com', '18-07-2022 04:10:43am', 'logout', 'Chrome'),
(140, '24GdDheABa60Ii9J8f1Fc5bCg7j3EH', '18-07-2022 04:10:57am', 'login', 'Chrome'),
(141, 'veronica@gmail.com', '18-07-2022 05:19:16am', 'logout', 'Chrome'),
(142, 'ea49gHb8F1ij507JA6ECDG3cBf2dIh', '18-07-2022 05:19:29am', 'login', 'Chrome'),
(143, 'amarogath94@gmail.com', '18-07-2022 06:11:37am', 'logout', 'Chrome'),
(144, '24GdDheABa60Ii9J8f1Fc5bCg7j3EH', '18-07-2022 06:11:59am', 'login', 'Chrome'),
(145, 'veronica@gmail.com', '18-07-2022 06:30:30am', 'logout', 'Chrome'),
(146, '24GdDheABa60Ii9J8f1Fc5bCg7j3EH', '18-07-2022 06:48:20am', 'login', 'Chrome'),
(147, 'veronica@gmail.com', '18-07-2022 07:57:45am', 'logout', 'Chrome'),
(148, '24GdDheABa60Ii9J8f1Fc5bCg7j3EH', '18-07-2022 07:59:48am', 'login', 'Chrome'),
(149, 'veronica@gmail.com', '18-07-2022 09:52:14am', 'logout', 'Chrome'),
(150, 'ea49gHb8F1ij507JA6ECDG3cBf2dIh', '18-07-2022 09:52:28am', 'login', 'Chrome'),
(151, 'amarogath94@gmail.com', '18-07-2022 09:59:40am', 'logout', 'Chrome'),
(152, 'ea49gHb8F1ij507JA6ECDG3cBf2dIh', '18-07-2022 10:09:33am', 'login', 'Chrome'),
(153, 'amarogath94@gmail.com', '18-07-2022 01:34:59pm', 'logout', 'Chrome'),
(154, '3hAbI7Ea5ig8FcJ12HdBf6e4DGj90C', '18-07-2022 01:35:09pm', 'login', 'Chrome'),
(155, 'amanirogath@gmail.com', '18-07-2022 01:36:34pm', 'logout', 'Chrome'),
(156, 'Df56c08Aj4Eea79gHiJBbGId2C1hF3', '18-07-2022 01:36:42pm', 'login', 'Chrome'),
(157, 'Df56c08Aj4Eea79gHiJBbGId2C1hF3', '18-07-2022 01:42:19pm', 'login', 'Chrome'),
(158, 'Df56c08Aj4Eea79gHiJBbGId2C1hF3', '18-07-2022 01:42:51pm', 'login', 'Chrome'),
(159, 'amanirogath@gmail.com', '18-07-2022 01:49:30pm', 'logout', 'Chrome'),
(160, 'Df56c08Aj4Eea79gHiJBbGId2C1hF3', '18-07-2022 01:53:35pm', 'login', 'Chrome'),
(161, 'amanirogath@gmail.com', '18-07-2022 01:59:49pm', 'logout', 'Chrome');

-- --------------------------------------------------------

--
-- Table structure for table `metrics`
--

CREATE TABLE `metrics` (
  `id` int(11) NOT NULL,
  `child_id` varchar(255) NOT NULL,
  `tempereture` int(11) NOT NULL,
  `height` int(11) NOT NULL,
  `weight` int(11) NOT NULL,
  `muac` int(11) NOT NULL,
  `date` varchar(40) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `metrics`
--

INSERT INTO `metrics` (`id`, `child_id`, `tempereture`, `height`, `weight`, `muac`, `date`, `status`) VALUES
(1, '1', 88, 22, 88, 88, '22-05-2022 03:24:56pm', 'B.M.I - MNENEJoto - LIPO JUUUpana wa mkono-KAWAIDA'),
(2, '1', 8, 11, 8, 8, '22-05-2022 03:26:03pm', 'B.M.I - MNENE, Joto - LIPO CHINI, Upana wa mkono-K'),
(3, '1', 8, 8, 11, 8, '22-05-2022 03:27:19pm', 'B.M.I - MNENE, Joto - LIPO CHINI, Upana wa mkono-K'),
(4, '1', 45, 44, 33, 14, '22-05-2022 03:28:50pm', 'B.M.I - MNENE, Joto - LIPO JUU, Upana wa mkono-KAW'),
(5, '1', 8, 8, 8, 8, '22-05-2022 03:29:49pm', 'B.M.I - MNENE, Joto - LIPO CHINI, Upana wa mkono-KIWANGO CHA CHINI SANA-HATARI');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `categories` varchar(255) NOT NULL,
  `parentgroups` varchar(255) NOT NULL,
  `time` varchar(50) NOT NULL,
  `author` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`id`, `title`, `description`, `categories`, `parentgroups`, `time`, `author`) VALUES
(9, 'qawstrfgw edrfghj', 'zxdcfgvbhjnmk\r\n', 'Chakula', 'Mwezi 0-3', '22-05-2022 12:02:33pm', 'amarogath94@gmail.com'),
(10, 'uhbhbubhub', 'ouhkjjkbkjbikj', 'Tahathari', 'Mwezi 4-7', '19-06-2022 10:03:36pm', 'amanirogath@gmail.com'),
(12, 'amani test', 'zzz', 'Afya', 'Mwezi 4-7', '18-07-2022 09:53:39am', 'amarogath94@gmail.com'),
(13, 'amani test', 'zzz', 'Afya', 'Mwezi 4-7', '18-07-2022 09:54:41am', 'amarogath94@gmail.com'),
(14, 'amani test', 'zzz', 'Afya', 'Mwezi 4-7', '18-07-2022 09:55:35am', 'amarogath94@gmail.com'),
(15, 'zzz', 'aaaa', 'Chakula', 'Mwezi 4-7', '18-07-2022 10:10:10am', 'amarogath94@gmail.com'),
(16, 'kkml', 'lkklml', 'Afya', 'Mwezi 4-7', '18-07-2022 11:04:41am', 'amarogath94@gmail.com'),
(17, 'klm', 'mklkmkmkl', 'Chakula', 'Mwezi 4-7', '18-07-2022 11:07:57am', 'amarogath94@gmail.com'),
(18, 'klmlkm', 'lklmklm', 'Tahathari', 'Mwezi 8-9', '18-07-2022 11:09:36am', 'amarogath94@gmail.com'),
(19, 'asd', 'asdf', 'Afya', 'Mwezi 8-9', '18-07-2022 11:12:27am', 'amarogath94@gmail.com'),
(20, 'asdf', 'asdcv b', 'Afya', 'Mwezi 8-9', '18-07-2022 11:14:06am', 'amarogath94@gmail.com'),
(21, 'hhhbhjb', 'jjkjjj', 'Chakula', 'Mwezi 4-7', '18-07-2022 11:15:53am', 'amarogath94@gmail.com'),
(22, 'nnn', 'kkk', 'Chakula', 'Mwezi 8-9', '18-07-2022 11:19:17am', 'amarogath94@gmail.com'),
(23, 'nini', 'jii', 'Tahathari', 'Mwezi 4-7', '18-07-2022 11:21:05am', 'amarogath94@gmail.com'),
(24, 'kko', 'ooko', 'Chakula', 'Mwezi 4-7', '18-07-2022 11:31:19am', 'amarogath94@gmail.com'),
(25, 'sdfb', 'SDFGBN', 'Chakula', 'Mwezi 4-7', '18-07-2022 11:32:55am', 'amarogath94@gmail.com'),
(26, 'sss', 'ooo', 'Afya', 'Mwezi 8-9', '18-07-2022 11:34:51am', 'amarogath94@gmail.com'),
(27, 'mm', 'nn', 'Afya', 'Mwezi 0-3', '18-07-2022 11:35:54am', 'amarogath94@gmail.com'),
(28, 'amani test 2022', 'amani amani amani', 'Afya', 'Mwezi 8-9', '18-07-2022 11:44:27am', 'amarogath94@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `readlog`
--

CREATE TABLE `readlog` (
  `id` int(11) NOT NULL,
  `postid` varchar(255) NOT NULL,
  `userid` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `readlog`
--

INSERT INTO `readlog` (`id`, `postid`, `userid`) VALUES
(4, '6', 'norah@gmail.com'),
(5, '7', 'norah@gmail.com'),
(6, '6', 'veronica@gmail.com'),
(7, '7', 'veronica@gmail.com'),
(8, '8', 'veronica@gmail.com'),
(9, '9', 'veronica@gmail.com'),
(10, '9', 'norah@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `special_id` varchar(255) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `email` varchar(200) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `region` varchar(255) NOT NULL,
  `district` varchar(255) NOT NULL,
  `ward` varchar(255) NOT NULL,
  `street` varchar(255) NOT NULL,
  `due` varchar(30) NOT NULL,
  `threemonth` varchar(20) NOT NULL,
  `onemonth` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `special_id`, `fullname`, `email`, `phone`, `region`, `district`, `ward`, `street`, `due`, `threemonth`, `onemonth`, `status`, `password`) VALUES
(8, '24GdDheABa60Ii9J8f1Fc5bCg7j3EH', 'igor itenko', 'yosemallya@gmail.com', '255621963150', 'arusha', '', 'sokoni', '', '2022-12-25', '', '', 'bado', '$2y$10$6luSpcaa6yFMqJjSAsB8meOTRdZ7j9bL4DybdQeaTtgMmkplE4DRG'),
(9, 'Df56c08Aj4Eea79gHiJBbGId2C1hF3', 'iii', 'amanirogath@gmail.com', '255743722720', 'arusha', 'sakina', 'ngaramtoni', 'njiro', '2022-12-10', '', '', 'bado', '$2y$10$PLVjr8KVMT9SR7HZtOZDreDaTlMU/m4WtipU1ga8nh6MTYi894cF2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `answers`
--
ALTER TABLE `answers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `center`
--
ALTER TABLE `center`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `checker`
--
ALTER TABLE `checker`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `children`
--
ALTER TABLE `children`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inquiries`
--
ALTER TABLE `inquiries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `metrics`
--
ALTER TABLE `metrics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `readlog`
--
ALTER TABLE `readlog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `answers`
--
ALTER TABLE `answers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `center`
--
ALTER TABLE `center`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `checker`
--
ALTER TABLE `checker`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `children`
--
ALTER TABLE `children`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `inquiries`
--
ALTER TABLE `inquiries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `log`
--
ALTER TABLE `log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=162;

--
-- AUTO_INCREMENT for table `metrics`
--
ALTER TABLE `metrics`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `readlog`
--
ALTER TABLE `readlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
