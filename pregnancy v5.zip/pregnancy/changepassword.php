<?php
session_start();
require("conn.php");
$message="";

$aidi=$_SESSION['who'];

if(isset($_POST['kawaida'])){
    $old=$_POST['old'];
    $new=$_POST['new'];
    $ret=$_POST['rep'];
   
    
$cal="SELECT `password` FROM `admins` WHERE `email`='$aidi'";
$ly=mysqli_query($connect,$cal);

$ff=mysqli_fetch_array($ly);

$pasy=$ff['password'];

$ver=password_verify($old,$pasy);

if($ver){
    
    if($new==$ret){
        $hash=password_hash($new,PASSWORD_DEFAULT);

    
    $zam="UPDATE `admins` SET `password`='$hash' WHERE `email`='$aidi'";
 
    $isha=mysqli_query($connect,$zam);

    if($isha){
        $message="<div class='alert alert-success alert-dismissible fade show'>
    <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span>
    </button> <strong>Hongera!</strong>Nwila imebadilishwa.</div>";
    }
    else{
        $message="<div class='alert alert-danger alert-dismissible fade show'>
        <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span>
        </button> <strong>Angalizo!</strong>Haiwezi Kubadilisha Nywila.</div>";
    }
    }
    else{
        $message="<div class='alert alert-warning alert-dismissible fade show'>
        <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span>
        </button> <strong>Angalizo!</strong>Nywila Mpya Haziendani.</div>";
    }

    
}

else{
    $message="<div class='alert alert-warning alert-dismissible fade show'>
        <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span>
        </button> <strong>Angalizo!</strong>Nywila Za Zamani Haziendani.</div>";
}
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>F.N.P.W.A | Badili Nywila</title>

    <link href="css/style.css" rel="stylesheet">

</head>

<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
   
    <div id="main-wrapper">

  <?php 
    require("nav.php");
  ?>

        <div class="content-body">


        <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Badili Nywila</h4>
                                <div class="basic-form">
                                    <form method="post">
                                    <div class="form-group">
                                  <?php echo $message; ?>

                                     </div>
                                   
                                        <div class="form-group">
                                            <input type="password" class="form-control input-default" name="old" placeholder="Andika Nywila Ya Zamani" required="required">
                                        </div>
                                        <div class="form-group">
                                            <input type="password" class="form-control input-default" name="new" placeholder="Andika Nywila Mpya" required="required">
                                        </div>
                                        <div class="form-group">
                                            <input type="password" class="form-control input-default" name="rep" placeholder="Rudia Kuandika Nywila Mpya" required="required">
                                        </div>
                                       
                                        <div class="form-group">
                                        <button type="submit" name="kawaida" class="btn mb-1 btn-success">Badili Nywila</button>
                                        </div>
                                       
                                    </form>
                                </div>
                            </div>
                        </div>
                     </div>   

                     </div>

                 </div>
        
        <!--**********************************
            Content body end
        ***********************************-->
        
        
</div>
    </div>
  
    <script src="plugins/common/common.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/settings.js"></script>
    <script src="js/gleek.js"></script>
    <script src="js/styleSwitcher.js"></script>

  
</body>

</html>