$(function () {

    // form submition
    $("#form").submit(function (e) {
        e.preventDefault()



        // input value for name
        let name = $("#name").val()

        alert($(this).attr('action'))

        // ajax post to php
        $.ajax({
            type: $(this).attr('method'),
            url: $(this).attr('action'),
            data: { name: name },
            dataType: "json",
            beforeSend: function () {
                $("#data").text('loading...')
            },
            success: function (response) {
                //console.log(response);
                if (response.status == 200) {
                    $("#data").text('This is ' + response.name);
                    $('#form')[0].reset()
                } else {
                    $("#data").text("No Data Found!")
                    $('#form')[0].reset()
                }
            },
            error: function (e) {
                alert(e)
            },
            complete: function () {
                console.log('compelete');
            }
        })
    })
});
