// jquery for register1 select show drop down
$(document).ready(function () {
    $(document).on('change', '#atype', function () {
        $('#blevel').val("");
        $('#clevel').val("");
        var a1 = $(this).val();
        $('#message').val("")

        if (a1 == 'g') {
            $('#blevel').val("");
            $('#clevel').val("");
            $('#message').val("")
            $('#blevel').val("").css('display', 'block');
            $('#clevel').css('display', 'none');
            $('#dlevel').css('display', 'none');


            $(document).on('change', '#btype', function () {
                var b1 = $('#btype').val();
                if(b1=='n'){
                    $("#message").text("Hongera Unamaendeleo mazuri,endelea kula vyakula vyenye madini na vitamini kwa wingi")
                } else if(b1=='h'){
                    $("#message").text("Jitahidi ufike kwenye kituo cha afya wewena mwenzi wako")
                }else{
                    $("#message").text("")
                }
            })

        } else if(a1=='b'){
            $('#message').val("")
            $('#blevel').css('display', 'none');
            $('#clevel').css('display', 'block');
            $('#dlevel').css('display', 'none');


            $(document).on('change', '#ctype', function () {
                var c1 = $('#ctype').val();
                if(c1=='al1'){
                    $("#message").text("")
                    $('#dlevel').css('display', 'block');

                    $(document).on('change', '#dtype', function () {
                        var d1 = $('#dtype').val();
                        if(d1=='all1'){
                            $("#message").text("Unaweza kutumia maharage ya soya ambayo yana virutubisho sawa na karanga")
                        } else if(d1=='all2'){
                            $("#message").text("unaweza kutumia mihogo na magimbi,yana virutubisho zaidi ya viazi")
                        } else if(d1=='all3'){
                            $("#message").text("unaweza kutumia samaki na kuku kama mbadala wa nyama")
                        } else if(d1=='all4'){
                            $("#message").text("unaweza kutumia mayai na nyama kama mbadala")
                        } else if(d1=='all5'){
                            $("#message").text("unaweza kutumia nyama na maziwa kama mbadala")
                        }
                        else{
                            $("#message").text("")
                        }
                    })

                } else if(c1=='al2'){
                    $('#dlevel').css('display', 'none');
                    $("#message").text("Epuka kazi ngumu na msongo wa mawazo,na maumivu yakizidi tafadhali fika katika kituo cha afya")
                }else if(c1=='al3'){
                    $('#dlevel').css('display', 'none');
                    $("#message").text("Kunywa maji kwa wingi na jitahidi ukamuone daktari")
                }else if(c1=='al4'){
                    $('#dlevel').css('display', 'none');
                    $("#message").text("Jitahidi kupumzika na kupunguza kazi ngumu na uchovu ukizidi kamuone daktari")
                }
                else{
                    $('#dlevel').css('display', 'none');
                    $("#message").text("")
                }
            })

        }else {
            $('#blevel').val("");
            $('#clevel').val("");
            $('#message').val("")
            $('#blevel').css('display', 'none');
            $('#clevel').css('display', 'none');
            $('#dlevel').css('display', 'none');

        }
    });
});