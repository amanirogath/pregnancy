<?php
session_start();
require("conn.php");


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>F.N.P.W.A | Viongozi</title>

    <link href="plugins/tables/css/datatable/dataTables.bootstrap4.min.css" rel="stylesheet">

    <link href="css/style.css" rel="stylesheet">

</head>

<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
   
    <div id="main-wrapper">

  <?php 
    require("nav.php");
  ?>

        <div class="content-body">

          
                 
        <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                              
                               <h4 class="card-title">Viongozi</h4>
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered zero-configuration">
                                        <thead>
                                            <tr>
                                                <th>Namba</th>
                                                <th>Majina Kamili</th>
                                                <th>Barua Pepe</th>
                                                <th>Phone</th>
                                                <th>Cheo</th>
                                                <th></th>
                                                <th> <a href="addstaff.php"> <button type="button" class="btn mb-1 btn-primary">Ongeza Kiongozi</button> </a></th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                        <?php
                                        // SELECT `id`, `special_id`, `full_name`, `email`, `phone`, `cheo`, `password` FROM `admins` WHERE 1
                                        $re="SELECT * FROM `admins`";
                                        $cfr=mysqli_query($connect,$re);
                                        $a=1;

                                   
                                        while ($fe=mysqli_fetch_array($cfr)) {

                                            echo' <tr>
                                            <td>'.$a.'</td>
                                            <td>'.$fe['full_name'].'</td>
                                            <td>'.$fe['email'].'</td>
                                            <td>'.$fe['phone'].'</td>
                                            <td>'.$fe['cheo'].'</td>
                                            <td><a class="btn mb-1 btn-info" href="editstaff.php?key='.$fe['special_id'].'">Badili</a></td>
                                            <td><a class="btn mb-1 btn-danger" href="deletestaff.php?key='.$fe['special_id'].'">Futa</a></td>
                                        </tr>
                                           ';
                                            $a++;
                                           }
                                           
                                            ?>
                                            
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                            <th>Namba</th>
                                                <th>Majina Kamili</th>
                                                <th>Barua Pepe</th>
                                                <th>Phone</th>
                                                <th>Cheo</th>
                                                <th></th>
                                                <th></th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #/ container -->
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
        
        
       
    </div>
  
    <script src="plugins/common/common.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/settings.js"></script>
    <script src="js/gleek.js"></script>
    <script src="js/styleSwitcher.js"></script>

    <script src="plugins/tables/js/jquery.dataTables.min.js"></script>
    <script src="plugins/tables/js/datatable/dataTables.bootstrap4.min.js"></script>
    <script src="plugins/tables/js/datatable-init/datatable-basic.min.js"></script>

  
</body>

</html>