<?php
session_start();
require("conn.php");

// INSERT INTO `admins`(`id`, `special_id`, `full_name`, `email`, `phone`, `cheo`, `password`)

$message="";

if(isset($_POST['enda'])){

    $c=mysqli_real_escape_string($connect,trim(htmlspecialchars($_POST['cname'])));
    $r=mysqli_real_escape_string($connect,trim(htmlspecialchars($_POST['region'])));
    $d=mysqli_real_escape_string($connect,trim(htmlspecialchars($_POST['district'])));
    $w=mysqli_real_escape_string($connect,trim(htmlspecialchars($_POST['ward'])));
    $s=mysqli_real_escape_string($connect,trim(htmlspecialchars($_POST['street'])));
    $o=mysqli_real_escape_string($connect,trim(htmlspecialchars($_POST['time'])));
    $e=mysqli_real_escape_string($connect,trim(htmlspecialchars($_POST['em'])));

$a="Mkoa-".$r.",Wilaya-".$d.",Kata-".$w.",Mtaa/Kijiji-".$s." .";
  
        // INSERT INTO `center`(`name`, `region`, `district`, `ward`, `street`, `address`, `opentime`, `emergency`)

    $al="INSERT INTO `center`(`name`, `region`, `district`, `ward`, `street`, `address`, `opentime`, `emergency`) 
    VALUES('$c','$r','$d','$w','$s','$a','$o','$e')";
 $isha=mysqli_query($connect,$al);
 
 if($isha){
   header("location:center.php");
}
else{
    $message="<div class='alert alert-danger alert-dismissible fade show'>
    <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span>
    </button> <strong>Angalizo!</strong>Taarifa hazijaenda.</div>";
}
    

}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>F.N.P.W.A | ongeza kituo</title>

    <link href="plugins/tables/css/datatable/dataTables.bootstrap4.min.css" rel="stylesheet">

    <link href="css/style.css" rel="stylesheet">

</head>

<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
   
    <div id="main-wrapper">

  <?php 
    require("nav.php");
  ?>

        <div class="content-body">

          
        <div class="container-fluid">


<div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Jaza Taarifa za kituo</h4>
                        <div class="basic-form">
                            <form method="post">
                            <div class="form-group">
                          <?php echo $message; ?>

                             </div>
                             <!-- // INSERT INTO `center`(`name`, `region`, `district`, `ward`, `street`, `address`, `opentime`, `emergency`) -->

                               <div class="form-group">
                                    <input type="text" class="form-control input-default" name="cname" placeholder="jina la kituo" required="required">
                                </div>

                                <div class="form-group">
                                    <input type="text" class="form-control input-default" name="region" placeholder="mkoa" required="required">
                                </div>

                                <div class="form-group">
                                    <input type="text" class="form-control input-default" name="district" placeholder="wilaya" required="required">
                                </div>

                                <div class="form-group">
                                    <input type="text" class="form-control input-default" name="ward" placeholder="kata" required="required">
                                </div>

                                <div class="form-group">
                                    <input type="text" class="form-control input-default" name="street" placeholder="mtaa au kijiji" required="required">
                                </div>

                                <div class="form-group">
                                    <input type="text" class="form-control input-default" name="time" placeholder="muda wa kufungua (mfano saa 2 asuhuhi mpaka saa 11 jioni au masaa 24)" required="required">
                                </div>

                                <div class="form-group">
                                    <input type="text" class="form-control input-default" name="em" placeholder="namba ya tharura" required="required">
                                </div>
                        
                                <div class="form-group">
                                <button type="submit" name="enda" class="btn mb-1 btn-success">Tuma Taarifa</button>
                                </div>
                               
                            </form>
                        </div>
                    </div>
                </div>
             </div>   

             </div>

         </div>
        
      
        <!--**********************************
            Content body end
        ***********************************-->
        
        
       
    </div>
  
    <script src="plugins/common/common.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/settings.js"></script>
    <script src="js/gleek.js"></script>
    <script src="js/styleSwitcher.js"></script>


  
</body>

</html>