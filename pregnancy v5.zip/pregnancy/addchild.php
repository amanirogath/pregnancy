<?php
session_start();
require("conn.php");


$who=$_SESSION['who'];
$message="";

if(isset($_POST['kawaida'])){
    
    $name=$_POST['name'];
    $bdate=$_POST['bdate'];
    $place=$_POST['place'];
    $gender=$_POST['gender'];

    // INSERT INTO `children`(`id`, `fullname`, `bithdate`, `parentid`, `placeofbirth`, `gender`) VALUES ('[value-1]','[value-2]','[value-3]','[value-4]','[value-5]','[value-6]')


$al="INSERT INTO `children`( `fullname`, `birthdate`, `parentid`, `placeofbirth`, `gender`) VALUES ('$name','$bdate','$who','$place','$gender')";


 $isha=mysqli_query($connect,$al);
 
 if($isha){
  header("location:mychildren.php");
}
else{
    $message="<div class='alert alert-warning alert-dismissible fade show'>
    <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span>
    </button> <strong>Angalizo!</strong>Taarifa hazijaenda.</div>";
    
}
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>F.N.P.W.A | Watoto</title>

    <link href="css/style.css" rel="stylesheet">

</head>

<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
   
    <div id="main-wrapper">

  <?php 
    require("navuser.php");
  ?>

        <div class="content-body">

        
        <!--**********************************
            Content body end
        ***********************************-->
        <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Sajili Mtoto</h4>
                                <div class="basic-form">
                                    <form method="post">
                                    <div class="form-group">
                                  <?php echo $message; ?>

                                     </div>
                                    
                                        <div class="form-group">
                                            <input type="text" class="form-control input-default" name="name" placeholder="Majina Kamili Ya Mtoto" required="required">
                                        </div>  
                                        <div class="form-group">
                                            <input type="date" class="form-control input-default" name="bdate" required="required">
                                        </div>  
                                        <div class="form-group">
                                            <input type="text" class="form-control input-default" name="place" placeholder="Mahali Pa Kuzaliwa" required="required">
                                        </div>
                                        <div class="form-group">
                                            <?php
                                        $whoo=$_SESSION['who'];
    $zzre="SELECT * FROM `users` WHERE `email`='$whoo'";
    $zzcfr=mysqli_query($connect,$zzre);
    $zzfe=mysqli_fetch_array($zzcfr);
    $nani=$zzfe['special_id'];
    $namez=$zzfe['fullname'];
    ?>
                                            <input type="text" class="form-control input-default" value="Mzazi - <?php echo $namez;?>" disabled="disabled">
                                        </div>
                                      
                                        <div class="form-group">
                                            <label>Jinsia:</label>
                                            <select name="gender" class="form-control" id="sel2">
                                                <option value="male">male</option>
                                                <option value="female">female</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                        <button type="submit" name="kawaida" class="btn mb-1 btn-success">Tuma Taarifa</button>
                                        </div>
                                       
                                    </form>
                                </div>
                            </div>
                        </div>
                     </div>   

                     </div>

                 </div>
         

               
       
    </div>
    </div>
  
    <script src="plugins/common/common.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/settings.js"></script>
    <script src="js/gleek.js"></script>
    <script src="js/styleSwitcher.js"></script>

  
</body>

</html>