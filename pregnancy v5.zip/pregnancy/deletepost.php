<?php
require("conn.php");
$t=$_GET['key'];

$futa="DELETE FROM `post` WHERE id='$t'";
$ff=mysqli_query($connect,$futa);



header("location:post.php");

?>