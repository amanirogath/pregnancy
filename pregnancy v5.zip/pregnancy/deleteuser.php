<?php
require("conn.php");
$t=$_GET['key'];

$futa="DELETE FROM `users` WHERE special_id='$t'";
$ff=mysqli_query($connect,$futa);



header("location:parents.php");

?>