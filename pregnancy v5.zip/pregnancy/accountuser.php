<?php
session_start();
require("conn.php");

$message="";
$who=$_SESSION['who'];


if(isset($_POST['bad'])){
    $name=$_POST['fullname'];
    $phone=$_POST['phone'];
    $ad=$_POST['adr'];
    $dt=$_POST['dt'];
   
    // UPDATE `users` SET `id`='[value-1]',`special_id`='[value-2]',`fullname`='[value-3]',`email`='[value-4]',
    // `phone`='[value-5]',`address`='[value-6]',`due`='[value-7]',`photo`='[value-8]',`status`='[value-9]',`password`='[value-10]' WHERE 1

$zam="UPDATE `users` SET `fullname`='$name',`phone`='$phone',`address`='$ad',`due`='$dt' WHERE `email`='$who'";
 
 $isha=mysqli_query($connect,$zam);
 
 if($isha){
     
    $message="<div class='alert alert-success alert-dismissible fade show'>
    <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span>
    </button> <strong>Hongera!</strong>Taarifa Zimebadilishwa.</div>";
}
else{
    $message="<div class='alert alert-danger alert-dismissible fade show'>
    <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span>
    </button> <strong>Angalizo!</strong>Hauwezi kubadili taarifa.</div>";
}
}



$rez="SELECT * FROM `users` WHERE `email`='$who'";
$cfrz=mysqli_query($connect,$rez);
$fez=mysqli_fetch_array($cfrz);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>F.N.P.W.A | Akaunti Yangu</title>

    <link href="css/style.css" rel="stylesheet">

</head>

<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
   
    <div id="main-wrapper">

  <?php 
    require("navuser.php");
  ?>

        <div class="content-body">

        <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Taarifa Zangu</h4>
                                <div class="basic-form">
                                    <form method="post">
                                    <div class="form-group">
                                  <?php echo $message; ?>

                                     </div>
                                    <div class="form-group">
                                            <input type="text" class="form-control input-default" name="who" placeholder="" value="Barua pepe - <?php echo $who;?>" disabled="disabled">
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control input-default" name="fullname" placeholder="Majina kamili" value="<?php echo $fez['fullname'];?>" required="required">
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control input-default" name="phone" placeholder="Namba Ya Simu" value="<?php echo $fez['phone'];?>" required="required">
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control input-default" name="adr" placeholder="Majina kamili" value="<?php echo $fez['address'];?>" required="required">
                                        </div>
                                        <div class="form-group">
                                            <label for="date"><?php echo 'Siku Ya Kujifungua '.$fez['due'];?></label>
                                            <input type="date" class="form-control input-default" name="dt" required="required">
                                        </div>
                                        <div class="form-group">
                                        <button type="submit" name="bad" class="btn mb-1 btn-success">Badili Taarifa</button>
                                        </div>
                                       
                                    </form>
                                </div>
                            </div>
                        </div>
                     </div>   

                     </div>

                 </div>
        <!--**********************************
            Content body end
        ***********************************-->
        
        
</div>
    </div>
  
    <script src="plugins/common/common.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/settings.js"></script>
    <script src="js/gleek.js"></script>
    <script src="js/styleSwitcher.js"></script>

  
</body>

</html>