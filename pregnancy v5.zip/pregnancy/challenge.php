<?php
$api_key='8a998c13deb847b0';
$secret_key = 'ZjU0MDQ3ZmUzYmIzMjAxMWVmNGRlNjRlM2NmM2M5NzZjMGQ2MGQ3OTIzNzhjMDlhZDhlNDRjMTk3MDQxNzdlYw==
';

$postData = array(
    'source_addr' => 'INFO',
    'encoding'=>0,
    'schedule_time' => '',
    'message' => 'Taarifa ya posti | F.N.P.W.A , Habari tumeongeza taarifa mpya kwenye mfumo wetu, pitia kwenye mfumo kwa maelezo zaidi',
    // 'recipients' => [array('recipient_id' => '1','dest_addr'=>'255700000001'),array('recipient_id' => '2','dest_addr'=>'255700000011')]
    'recipients' => [array('recipient_id' => '1','dest_addr'=>'255743722720')]
);

$Url ='https://apisms.beem.africa/v1/send';

$ch = curl_init($Url);
error_reporting(E_ALL);
ini_set('display_errors', 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt_array($ch, array(
    CURLOPT_POST => TRUE,
    CURLOPT_RETURNTRANSFER => TRUE,
    CURLOPT_HTTPHEADER => array(
        'Authorization:Basic ' . base64_encode("$api_key:$secret_key"),
        'Content-Type: application/json'
    ),
    CURLOPT_POSTFIELDS => json_encode($postData)
));

$response = curl_exec($ch);

if($response === FALSE){
        echo $response;

    die(curl_error($ch));
}
var_dump($response);

?>