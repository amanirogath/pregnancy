<?php

if(time() - $_SESSION['timestamp'] > 90) { //subtract new timestamp from the old one
    unset($_SESSION['timestamp']);
    header("Location:lock.php"); //redirect to lock.php
} 

else {
    $_SESSION['timestamp'] = time(); //set new timestamp
}

?>