<?php
session_start();
require("conn.php");

$message="";

$who=$_SESSION['who'];
if(empty($_SESSION['who'])){
    header("location:index.php");
    die();

}
if(isset($_POST['tuma'])){
    
    $when=$_POST['tar'];



    $aidi=$_SESSION['who'];


    $al="UPDATE `users` SET`due`='$when' WHERE `email`='$aidi'";


 $isha=mysqli_query($connect,$al);
 
 if($isha){


    $message="<div class='alert alert-success alert-dismissible fade show'>
    <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span>
    </button> <strong>Hongera!</strong>Taarifa imetumwa.</div>";
}
else{
    echo $al;
    // $message="<div class='alert alert-warning alert-dismissible fade show'>
    // <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span>
    // </button> <strong>Angalizo!</strong>Taarifa hazijaenda.</div>";
    
}


}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>F.N.P.W.A | Taarifa za ujauzito</title>

    <link href="css/style.css" rel="stylesheet">

</head>

<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
   
    <div id="main-wrapper">

  <?php 
    require("navuser.php");
  ?>

        <div class="content-body">

        
        <div class="container-fluid mt-3">


             
        <div class="row">
    

           <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Taaarifa za ujauzito</h4>

                                <div class="basic-form">
                                    <form method="post">
                                    <div class="form-group">
                                  <?php echo $message; ?>

                                     </div>
                                   
                                        <div class="form-group">
                                            <label>Tarehe ya kujifungua (Uliyopewa kiliniki):</label>
                                            <input type="date" name="tar" required="required">
                                        </div>
                                   

                                        <div class="form-group">
                                        <button type="submit" name="tuma" class="btn mb-1 btn-success">Tuma taarifa</button>
                                        </div>
                                       
                                    </form>
                                </div>
                            </div>
                        </div>
                     </div>
                     
                     <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                            <h5>Tarehe ya unayo tarajia kujifungua</h5>

<?php 

 $re="SELECT * FROM `users`";
 $zzcfr=mysqli_query($connect,$re);
 $zzfe=mysqli_fetch_array($zzcfr);
 $nani=$zzfe['due'];
 echo "<p>".$nani."</p>";
?>


 <h5>Muda uilizo baki</h5>

<?php
 $today=date('Y-m-d');

 ?>

 <p>hhh</p>
 <p>hhh</p>

                           </div>
                         </div>
                     </div>  

         </div>
        <!--**********************************
            Content body end
        ***********************************-->
        
        
       
    </div>
    </div>
    </div>
  
    <script src="plugins/common/common.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/settings.js"></script>
    <script src="js/gleek.js"></script>
    <script src="js/styleSwitcher.js"></script>

  
</body>

</html>