<?php 
session_start();
require("conn.php");

$re="SELECT `datez` FROM `checker`";
$cfr=mysqli_query($connect,$re);
$fe=mysqli_fetch_array($cfr);
$ffe=$fe['datez'];

$yes=strtotime($ffe);


$tod=date('Y-m-d');
$today=strtotime($tod);

echo $today;
echo $yes;


if($today!==$yes){
    $uu="UPDATE `checker` SET `datez`='$tod'";
    $ucfr=mysqli_query($connect,$uu);
    

    //select due dates
    $zre="SELECT * FROM `users`";
    $zcfr=mysqli_query($connect,$zre);
    $a=1;

    while ($zfe=mysqli_fetch_array($zcfr)) {

      $id=$zfe['id'];
      $due=$zfe['due'];
      $em=$zfe['email'];
      $ph=$zfe['phone'];
      $tm=$zfe['threemonth'];
      $om=$zfe['onemonth'];

        $d1=strtotime($due);
        $cal=$d1-$today;
        $cal2=round($cal/86400);
        echo $cal2;
        
        if($cal2<=31 && $cal2>=1){
        
            if($om!=="yes"){

                  //sms
                  $api_key='8a998c13deb847b0';
                  $secret_key = 'ZjU0MDQ3ZmUzYmIzMjAxMWVmNGRlNjRlM2NmM2M5NzZjMGQ2MGQ3OTIzNzhjMDlhZDhlNDRjMTk3MDQxNzdlYw==
                  ';
                  
                  $postData = array(
                      'source_addr' => 'INFO',
                      'encoding'=>0,
                      'schedule_time' => '',
                      'message' => 'F.N.P.W.A | Habari,Imebaki mnamo mwezi mmoja ujifungue,tafathali uwe unahuthuria kituo cha afya kilichopo karibu yako mara kwa mara.',
                      // 'recipients' => [array('recipient_id' => '1','dest_addr'=>'255700000001'),array('recipient_id' => '2','dest_addr'=>'255700000011')]
                      'recipients' => [array('recipient_id' => $id,'dest_addr'=>$ph)]
                  );
                  
                  $Url ='https://apisms.beem.africa/v1/send';
                  
                  $ch = curl_init($Url);
                  error_reporting(E_ALL);
                  ini_set('display_errors', 1);
                  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                  curl_setopt_array($ch, array(
                      CURLOPT_POST => TRUE,
                      CURLOPT_RETURNTRANSFER => TRUE,
                      CURLOPT_HTTPHEADER => array(
                          'Authorization:Basic ' . base64_encode("$api_key:$secret_key"),
                          'Content-Type: application/json'
                      ),
                      CURLOPT_POSTFIELDS => json_encode($postData)
                  ));
                  
                  $response = curl_exec($ch);
                  
                  if($response === FALSE){
                          echo $response;
                  
                      die(curl_error($ch));
                  }
                  var_dump($response);
                  
                  //end sms
                  


        // echo "F.N.P.W.A | Habari,Imebaki mnamo mwezi mmoja ujifungue,tafathali uwe unahuthuria kituo cha afya kilichopo karibu yako mara kwa mara.";
      


        $ouu="UPDATE `users` SET `onemonth`='yes' WHERE `email`='$em'";
        $oucfr=mysqli_query($connect,$ouu);

               }
    }
        
        if($cal2>=32 && $cal2<=91){
            if($tm!=="yes"){

                //sms
                $api_key='8a998c13deb847b0';
$secret_key = 'ZjU0MDQ3ZmUzYmIzMjAxMWVmNGRlNjRlM2NmM2M5NzZjMGQ2MGQ3OTIzNzhjMDlhZDhlNDRjMTk3MDQxNzdlYw==
';

$postData = array(
    'source_addr' => 'INFO',
    'encoding'=>0,
    'schedule_time' => '',
    'message' => 'F.N.P.W.A | Habari,Imebaki mnamo miezi mitatu ujifungue, endelea kula vyakula vyenye vitamini na madini kwa wingi',
    // 'recipients' => [array('recipient_id' => '1','dest_addr'=>'255700000001'),array('recipient_id' => '2','dest_addr'=>'255700000011')]
    'recipients' => [array('recipient_id' => $id,'dest_addr'=>$ph)]
);

$Url ='https://apisms.beem.africa/v1/send';

$ch = curl_init($Url);
error_reporting(E_ALL);
ini_set('display_errors', 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt_array($ch, array(
    CURLOPT_POST => TRUE,
    CURLOPT_RETURNTRANSFER => TRUE,
    CURLOPT_HTTPHEADER => array(
        'Authorization:Basic ' . base64_encode("$api_key:$secret_key"),
        'Content-Type: application/json'
    ),
    CURLOPT_POSTFIELDS => json_encode($postData)
));

$response = curl_exec($ch);

if($response === FALSE){
        echo $response;

    die(curl_error($ch));
}
var_dump($response);

//end sms

            // echo "F.N.P.W.A | Habari,Imebaki mnamo miezi mitatu ujifungue, endelea kula vyakula vyenye vitamini na madini kwa wingi";
          
            $tuu="UPDATE `users` SET `threemonth`='yes' WHERE `email`='$em'";
            $tucfr=mysqli_query($connect,$tuu);
    
                   }
        }
        

            

        $a++;
       }

    //end 




}


?>