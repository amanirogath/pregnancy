<?php
require("conn.php");
$message="";

if(isset($_POST['login'])){
    $flname=mysqli_real_escape_string($connect,trim(htmlspecialchars($_POST['flname'])));
    $r=mysqli_real_escape_string($connect,trim(htmlspecialchars($_POST['mkoa'])));
    $d=mysqli_real_escape_string($connect,trim(htmlspecialchars($_POST['wilaya'])));
    $w=mysqli_real_escape_string($connect,trim(htmlspecialchars($_POST['kata'])));
    $s=mysqli_real_escape_string($connect,trim(htmlspecialchars($_POST['mtaa'])));
    $em=mysqli_real_escape_string($connect,trim(htmlspecialchars($_POST['email'])));
    $p=mysqli_real_escape_string($connect,trim(htmlspecialchars($_POST['phone'])));
    $dt=mysqli_real_escape_string($connect,trim(htmlspecialchars($_POST['due'])));
    $p1=mysqli_real_escape_string($connect,trim(htmlspecialchars($_POST['pass'])));
    $p2=mysqli_real_escape_string($connect,trim(htmlspecialchars($_POST['pass2'])));
    
    $sh=str_shuffle("ABCDEFGHIJabcdefghij1234567890");

    // $imagee = $_FILES['images']['name'];
    // $upd = "images/profile/".basename($imagee);
    //  move_uploaded_file($_FILES['images']['tmp_name'], $upd);


    if($p1==$p2){

        // INSERT INTO `users`(`id`, `special_id`, `fullname`, `email`, `phone`, `address`, `due`, `photo`, `status`, `password`) 

    $hush=password_hash($p1,PASSWORD_DEFAULT);
 $ins="INSERT INTO `users`(`special_id`,`fullname`,`email`,`phone`, `region`, `district`, `ward`, `street`,`due`,`status`,`password`)
 VALUES ('$sh','$flname','$em','$p','$r','$d','$w','$s','$dt','bado','$hush')";
 $ver=mysqli_query($connect,$ins);


 if($ver){
    $message="<div class='alert alert-success alert-dismissible fade show'>
    <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span>
    </button> <strong>Hongera!</strong>Umefanikiwa kujisajili, nenda kaingie kwenye mfumo.</div>";
 }
 else{
    
    $message="<div class='alert alert-danger alert-dismissible fade show'>
    <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span>
    </button> <strong>Kuna tatizo!</strong> Taarifa hazijaenda.</div>";
    // echo $ins;
 }

    }
    else{
        $message="<div class='alert alert-warning alert-dismissible fade show'>
    <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span>
    </button> <strong>Angalizo!</strong>Nywila hazifanani.</div>";
    }


}
?>

<!DOCTYPE html>
<html class="h-100" lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
    <link href="css/style.css" rel="stylesheet">

    <title>F.N.P.W.A | Register</title>
</head>

<body class="h-100">
    
    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    



    <div class="login-form-bg h-100">
        <div class="container h-100">
            <div class="row justify-content-center h-100">
                <div class="col-xl-6">
                    <div class="form-input-content">
                        <div class="card login-form mb-0">
                            <div class="card-body pt-5">
                                <a class="text-center" href=""> <h4>F.N.P.W.A | Jisajili kwenye Mfumo</h4></a>
        


<form method="post" enctype="multipart/form-data" class="mt-5 mb-5 login-input">
                                    <div class="form-group">
                                    <?php echo $message; ?>
                                    </div>

                                    <!-- // INSERT INTO `users`(`id`, `special_id`, `full name`, `email`, `phone`, `address`, `gender`, `photo`, `status`, `password`)  -->


                                    <div class="form-group">
                                        <input type="text" class="form-control" name="flname" placeholder="Majina Kamili" required="required">
                                    </div>

                                    <div class="form-group">
                                        <input type="email" class="form-control" name="email" placeholder="Barua Pepe" required="required">
                                    </div>

                                    <div class="form-group">
                                        <input type="text" class="form-control" name="phone" placeholder="Namba Ya Simu" required="required">
                                    </div>

                                    <div class="form-group">
                                        <input type="text" class="form-control" name="mkoa" placeholder="mkoa" required="required">
                                    </div>

                                    <div class="form-group">
                                        <input type="text" class="form-control" name="wilaya" placeholder="wilaya" required="required">
                                    </div>   

                                     <div class="form-group">
                                        <input type="text" class="form-control" name="kata" placeholder="kata" required="required">
                                    </div>  

                                      <div class="form-group">
                                        <input type="text" class="form-control" name="mtaa" placeholder="mtaa au kijiji" required="required">
                                    </div>

                                    <div class="form-group">
                                        <label>Siku Ya Kujifungua (ulivyo ambiwa kituoni)</label>
                                        <input type="date" class="form-control" name="due" required="required">
                                    </div>

                                    <div class="form-group">
                                        <input type="password" class="form-control" name="pass" placeholder="Nwila" required="required">
                                    </div>

                                    <div class="form-group">
                                        <input type="password" class="form-control" name="pass2" placeholder="Rudia Nwila" required="required">
                                    </div>
                                    <button  type="submit" name="login" class="btn login-form__btn submit w-100">Sajili</button>
                                
                                    </form>
                                        <p class="mt-5 login-form__footer"> Mtumiaji wa kawaida? <a href="index.php" class="text-primary">
                                        Ingia</a> &nbsp; | &nbsp; Umesahau Nywila? <a href="forget.php" class="text-primary">
                                        Rudisha Akaunti</a></p>
                               
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <script src="plugins/common/common.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/settings.js"></script>
    <script src="js/gleek.js"></script>
    <script src="js/styleSwitcher.js"></script>

</body>
</html>