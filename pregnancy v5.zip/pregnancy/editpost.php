<?php
session_start();
require("conn.php");
$message="";


$i=$_GET['key'];


if(isset($_POST['kawaida'])){
    $who="amani mworia";
    $title=$_POST['title'];
    $descr=$_POST['descr'];
    $cat=$_POST['cat'];
    $group=$_POST['group'];
  
   
     $when=date('d-m-Y');

// UPDATE `post` SET `id`='[value-1]',`title`='[value-2]',`description`='[value-3]',`time`='[value-4]',`author`='[value-5]' WHERE 1

$al="UPDATE `post` SET `title`='$title',`description`='$descr',`time`='$when',`categories`='$cat',`parentgroups`='$group',`author`='$who' WHERE `id`='$i'";

 $isha=mysqli_query($connect,$al);
 
 if($isha){

    header("location:post.php");
}
else{
    $message="<div class='alert alert-warning alert-dismissible fade show'>
    <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span>
    </button> <strong>Angalizo!</strong>Taarifa hazijaenda.</div>";
}
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>F.N.P.W.A | badili</title>

    <link href="plugins/tables/css/datatable/dataTables.bootstrap4.min.css" rel="stylesheet">

    <link href="css/style.css" rel="stylesheet">

</head>

<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
   
    <div id="main-wrapper">

  <?php 
    require("nav.php");
  ?>

        <div class="content-body">

        <div class="container-fluid">


        <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Andika Posti</h4>
                                <div class="basic-form">
                                    <form method="post">
                                   
                                  
                                     
                                     <?php
                                    $re="SELECT * FROM `post` WHERE `id`='$i'";
                                        $cfr=mysqli_query($connect,$re);
                                        $a=1;

                                   
                                      $fe=mysqli_fetch_array($cfr);

                                     ?>



                                    <div class="form-group">
                                        <?php echo $message;?>
                                     </div>
                                    <div class="form-group">
                                            <input type="text" class="form-control input-default" name="who" placeholder="" value="Mtumaji - amani rogath" disabled="disabled">
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control input-default" name="title" placeholder="kichwa cha habari" value="<?php echo $fe['title'];?>" required="required">
                                        </div>
                                        <div class="form-group">
                                            <label>Aina Ya Posti:</label>
                                            <select name="cat" class="form-control" id="sel1">
                                                <option value="Matunzo">Matunzo</option>
                                                <option value="Chakula">Chakula</option>
                                                <option value="Afya">Afya</option>
                                                <option value="Tahathari">Tahathari</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Kundi La Mzazi:</label>
                                            <select name="group" class="form-control" id="sel2">
                                                <option value="Wote">Wote</option>
                                                <option value="Mwezi 0-3">Mwezi 0-3</option>
                                                <option value="Mwezi 4-7">Mwezi 4-7</option>
                                                <option value="Mwezi 8-9">Mwezi 8-9</option>
                                                <option value="Walio Zaliwa">Walio Zaliwa</option>
                                            </select>
                                        </div>
                                       
                                        <div class="form-group">
                                        <label>Ujumbe:</label>
                                            <textarea class="form-control h-150px" rows="6" name="descr" id="Ujumbe" required="required"><?php echo $fe['description'];?></textarea>
                                        </div>
                                        <div class="form-group">
                                        <button type="submit" name="kawaida" class="btn mb-1 btn-success">Tuma ujumbe</button>
                                        </div>
                                       
                                    </form>
                                </div>
                            </div>
                        </div>
                     </div>   

                     </div>

                 </div>
         

                 
           
        </div>
       



        <!--**********************************
            Content body end
        ***********************************-->
        
        
       
    </div>
  
    <script src="plugins/common/common.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/settings.js"></script>
    <script src="js/gleek.js"></script>
    <script src="js/styleSwitcher.js"></script>


   
</body>

</html>