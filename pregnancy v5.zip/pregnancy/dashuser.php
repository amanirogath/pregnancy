<?php
session_start();
require("conn.php");

$who=$_SESSION['who'];
if(empty($_SESSION['who'])){
    header("location:index.php");
    die();

}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>F.N.P.W.A | Dashibodi</title>

    <link href="css/style.css" rel="stylesheet">

</head>

<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
   
    <div id="main-wrapper">

  <?php 
    require("navuser.php");
  ?>

        <div class="content-body">

        
        <div class="container-fluid mt-3">


             
        <div class="row">

<?php
                        // SELECT `id`, `title`, `description`, `time`, `author` FROM `post` WHERE 1
                        // $re="SELECT * FROM `post` LIMIT 12";
                        $re="SELECT * FROM `post`";
                        $cfr=mysqli_query($connect,$re);
                        $a=1;

                   
                        while ($fe=mysqli_fetch_array($cfr)) {

                        
                        
            echo'
    <div class="col-lg-3 col-sm-6">
        <div class="card">
            <div class="card-body">
                <div class="text-center">
                    <h5 class="mt-3 mb-1">'.$fe['title'].'</h5>
                    <p class="m-0">'.$fe['author'].'</p>
                    <p class="m-0" style="color:red">Aina - '.$fe['categories'].'</p>
                    <p class="m-0"style="color:blue">Kundi - '.$fe['parentgroups'].'</p>
                    <a href="readpost.php?key='.$fe['id'].'" class="btn btn-sm btn-warning">Soma</a>
                </div>
            </div>
        </div>
    </div>
    ';
    $a++;
   }
   
    ?>

 

</div>
        <!--**********************************
            Content body end
        ***********************************-->
        
        
       
    </div>
    </div>
    </div>
  
    <script src="plugins/common/common.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/settings.js"></script>
    <script src="js/gleek.js"></script>
    <script src="js/styleSwitcher.js"></script>

  
</body>

</html>