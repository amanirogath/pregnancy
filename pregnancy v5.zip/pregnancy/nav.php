<?php
if(empty($_SESSION['who'])){
    header("location:index.php");
    die();
}

if(empty($_SESSION['cheo'])){
    header("location:index.php");
    die();
}

// switch side menu according to title

if($_SESSION['cheo']=="admin"){
    include("subadmn.php");
}

if($_SESSION['cheo']=="doctor"){
    include("subdoc.php");
}

?>