<?php
define('HOST', 'localhost');
define('USER', 'root');
define('PASS', '');
define('DB', 'pregnancy');

$connect=mysqli_connect(HOST,USER,PASS,DB) or die("cannot connect to the database.");

?>