<?php
session_start();
require("conn.php");


$who=$_SESSION['who'];
$message="";

$i=$_GET['key'];

$rez="SELECT * FROM `children` WHERE `id`='$i'";
$cfrz=mysqli_query($connect,$rez);
$fez=mysqli_fetch_array($cfrz);
$rope=$fez['fullname'].' , '.$fez['birthdate'].' , '.$fez['placeofbirth'].' , '.$fez['gender'];


if(isset($_POST['kawaida'])){
    
    $h=$_POST['height'];
    $w=$_POST['weight'];
    $t=$_POST['temp'];
    $m=$_POST['muac'];
  

 
  $hm=$h/100;
  $bm=$hm*$hm;
  $bmi=$w/$bm; 
                 switch($bmi){
                              case ($bmi>=30):
                                $bmires="MNENE";
                                break;
                              case ($bmi<=13):
                                $bmires="UZITO UKO CHINI";
                                break; 
                              default:
                              $bmires="KAWAIDA";
                             }

                             switch($t){
                                case ($t>=37.5):
                                  $tempres="LIPO JUU";
                                  break;
                                case ($t<=35.9):
                                  $tempres="LIPO CHINI";
                                  break; 
                                default:
                                $tempres="KAWAIDA";
                               }

                               switch($m){
                                    case ($m>=6 && $m<=11.4):
                                    $muacres="KIWANGO CHA CHINI SANA-HATARI";
                                    break;
                                    case ($m>=11.5 && $m<=12.4):
                                    $muacres="KIWANGO CHA CHINI SANA";
                                    break; 
                                    case ($m>=12.5 && $m<=13.5):
                                    $muacres="KIWANGO CHA CHINI";
                                    break;
                                default:
                                $muacres="KAWAIDA";
                               }

$stat='B.M.I - '.$bmires.', Joto - '. $tempres.', Upana wa mkono-'.$muacres;


   
     $when=date('d-m-Y h:i:sa');

    //  INSERT INTO `metrics`(`id`, `child_id`, `tempereture`, `height`, `weight`, `muac`, `date`, `status`) VALUES ('[value-1]','[value-2]','[value-3]','[value-4]','[value-5]','[value-6]','[value-7]','[value-8]')

$al="INSERT INTO `metrics`(`child_id`, `tempereture`, `height`, `weight`, `muac`, `date`, `status`) VALUES ('$i','$t','$h','$w','$m','$when','$stat')";


 $isha=mysqli_query($connect,$al);
 
 if($isha){
    $message="<div class='alert alert-success alert-dismissible fade show'>
    <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span>
    </button> <strong>Hongera!</strong>Taarifa imetumwa.</div>";
}
else{
    $message="<div class='alert alert-warning alert-dismissible fade show'>
    <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span>
    </button> <strong>Angalizo!</strong>Taarifa hazijaenda.</div>";
    
}
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>F.N.P.W.A | Takwimu za mtoto</title>

    <link href="plugins/tables/css/datatable/dataTables.bootstrap4.min.css" rel="stylesheet">

    <link href="css/style.css" rel="stylesheet">

</head>

<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
   
    <div id="main-wrapper">

  <?php 
    require("navuser.php");
  ?>

        <div class="content-body">

        <div class="container-fluid">


        <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Ongeza Vipimo</h4>
                                <div class="basic-form">
                                    <form method="post">
                                    <div class="form-group">
                                  <?php echo $message; ?>

                                     </div>
                                     <div class="form-group">
                                            <input type="text" class="form-control input-default" placeholder="" value="<?php echo $rope;?>" disabled="disabled">
                                        </div>
                                       
                                     
                                     <div class="form-group">
                                            <input type="text" class="form-control input-default" name="height" placeholder="Urefu Wa Mtoto" required="required">
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control input-default" name="weight" placeholder="Uzito Wa Mtoto" required="required">
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control input-default" name="temp" placeholder="Joto La Mtoto" required="required">
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control input-default" name="muac" placeholder="Upana Wa Mkono Wa Mtoto" required="required">
                                        </div>
                                        <div class="form-group">
                                        <button type="submit" name="kawaida" class="btn mb-1 btn-success">Tuma vipimo</button>
                                        </div>
                                       
                                    </form>
                                </div>
                            </div>
                        </div>
                     </div>   

                     </div>

                 </div>
         

                 
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Hali Ya Mtoto</h4>
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered zero-configuration">
                                        <thead>
                                            <tr>
                                            <!-- SELECT `id`, `child_id`, `tempereture`, `height`, `weight`, `muac`, `date`, `status` FROM `metrics` WHERE 1 -->
                                                <th>Namba</th>
                                                <th>Joto</th>
                                                <th>Urefu</th>
                                                <th>Uzito</th>
                                                <th>Upana wa Mkono</th>
                                                <th>Tarehe</th>
                                                <th>Hali</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                        <?php
                                        $re="SELECT * FROM `metrics` WHERE `child_id`='$i'";
                                        $cfr=mysqli_query($connect,$re);
                                        $a=1;

           
                                        while ($fe=mysqli_fetch_array($cfr)) {
                                            
                                            echo' <tr>
                                            <td>'.$a.'</td>
                                            <td>'.$fe['tempereture'].'</td>
                                            <td>'.$fe['height'].'</td>
                                            <td>'.$fe['weight'].'</td>
                                            <td>'.$fe['muac'].'</td>
                                            <td>'.$fe['date'].'</td>
                                            <td>'.$fe['status'].'</td>
                                               </tr>
                                           ';
                                            $a++;
                                           }
                                           
                                            ?>
                                            
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                            <th>Namba</th>
                                                <th>Joto</th>
                                                <th>Urefu</th>
                                                <th>Uzito</th>
                                                <th>Upana wa Mkono</th>
                                                <th>Tarehe</th>
                                                <th>Hali</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #/ container -->
        </div>
       



        <!--**********************************
            Content body end
        ***********************************-->
        
        
       
    </div>
  
    <script src="plugins/common/common.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/settings.js"></script>
    <script src="js/gleek.js"></script>
    <script src="js/styleSwitcher.js"></script>


    <script src="plugins/tables/js/jquery.dataTables.min.js"></script>
    <script src="plugins/tables/js/datatable/dataTables.bootstrap4.min.js"></script>
    <script src="plugins/tables/js/datatable-init/datatable-basic.min.js"></script>

</body>

</html>