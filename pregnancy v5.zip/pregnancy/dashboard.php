<?php
session_start();
require("conn.php");

//for alerting users 
require("checker.php");

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>F.N.P.W.A | dashibodi</title>

    <link href="css/style.css" rel="stylesheet">

</head>

<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
   
    <div id="main-wrapper">

  <?php 
    require("nav.php");
  ?>

        <div class="content-body">

            <div class="container-fluid mt-3">
                <div class="row">
                    <div class="col-lg-3 col-sm-6">
                        <div class="card gradient-1">
                            <div class="card-body">

                            <?php 
$re21="SELECT * FROM `inquiries`";
$er21=mysqli_query($connect,$re21);
$total21=mysqli_num_rows($er21);
?>

<!-- Maswali Yalio Ulizwa -->
                                <h3 class="card-title text-white">Maswali</h3>
                                <div class="d-inline-block">
                                    <h2 class="text-white"><?php echo $total21;?></h2>
                                    <p class="text-white mb-0"><?php echo date('d-m-Y');?></p>
                                </div>
                                <span class="float-right display-5 opacity-5"><i class="fa fa-comment"></i></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="card gradient-2">
                            <div class="card-body">
                            <?php 
$re22="SELECT * FROM `post`";
$er22=mysqli_query($connect,$re22);
$total22=mysqli_num_rows($er22);
?>
                                <h3 class="card-title text-white">Posti</h3>
                                <div class="d-inline-block">
                                    <h2 class="text-white"><?php echo $total22;?></h2>
                                    <p class="text-white mb-0"><?php echo date('d-m-Y');?></p>
                                </div>
                                <span class="float-right display-5 opacity-5"><i class="fa fa-bookmark"></i></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="card gradient-3">
                            <div class="card-body">
                            <?php 
$re23="SELECT * FROM `users`";
$er23=mysqli_query($connect,$re23);
$total23=mysqli_num_rows($er23);
?>
                                <h3 class="card-title text-white">Wazazi</h3>
                                <div class="d-inline-block">
                                    <h2 class="text-white"><?php echo $total23;?></h2>
                                    <p class="text-white mb-0"><?php echo date('d-m-Y');?></p>
                                </div>
                                <span class="float-right display-5 opacity-5"><i class="fa fa-users"></i></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="card gradient-4">
                            <div class="card-body">
                            <?php 
$re24="SELECT * FROM `children`";
$er24=mysqli_query($connect,$re24);
$total24=mysqli_num_rows($er24);
?>
                                <h3 class="card-title text-white">Watoto</h3>
                                <div class="d-inline-block">
                                    <h2 class="text-white"><?php echo $total24;?></h2>
                                    <p class="text-white mb-0"><?php echo date('d-m-Y');?></p>
                                </div>
                                <span class="float-right display-5 opacity-5"><i class="fa fa-heart"></i></span>
                            </div>
                        </div>
                    </div>
                </div>

            

           

          

                
            </div>
            <!-- #/ container -->
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
        
        
       
    </div>
  
    <script src="plugins/common/common.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/settings.js"></script>
    <script src="js/gleek.js"></script>
    <script src="js/styleSwitcher.js"></script>

  
</body>

</html>