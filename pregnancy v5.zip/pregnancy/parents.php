<?php
session_start();
require("conn.php");


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>F.N.P.W.A | Wazazi</title>

    <link href="css/style.css" rel="stylesheet">

</head>

<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
   
    <div id="main-wrapper">

  <?php 
    require("nav.php");
  ?>

        <div class="content-body">

        
        <!--**********************************
            Content body end
        ***********************************-->
        <div class="container-fluid">




        <div class="row">
        <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                            <h4 class="card-title">Wazazi</h4>
                                <div class="active-member">
                                    <div class="table-responsive">
                                        <table class="table table-xs mb-0">
                                            <thead>

                                            <!-- SELECT `id`, `special_id`, `fullname`, `email`, `phone`, `address`, `due`, `photo`, `status`, `password` FROM `users` WHERE 1 -->
                                                <tr>
                                                    <th>#</th>
                                                    <th>Majina Kamili</th>
                                                    <th>Barua Pepe</th>
                                                    <th>Simu</th>
                                                    <th>Makazi</th>
                                                    <th>Siku Ya Kujifungua</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                   
                                                <?php
                                        $re="SELECT * FROM `users`";
                                        $cfr=mysqli_query($connect,$re);
                                        $a=1;

                                   
                                        while ($fe=mysqli_fetch_array($cfr)) {

                                            echo' <tr>
                                            <td>'.$a.'</td>
                                            <td>'.$fe['fullname'].'</td>
                                            <td>'.$fe['email'].'</td>
                                            <td>'.$fe['phone'].'</td>
                                            <td>'.$fe['address'].'</td>
                                            <td>'.$fe['due'].'</td>
                                            <td><a class="btn mb-1 btn-danger" href="deleteuser.php?key='.$fe['special_id'].'">Futa</a></td>
                                        </tr>
                                           ';
                                            $a++;
                                           }
                                           
                                            ?>
                                            
                                              
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>                        
                    </div>
                </div>



               
       
    </div>
    </div>
  
    <script src="plugins/common/common.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/settings.js"></script>
    <script src="js/gleek.js"></script>
    <script src="js/styleSwitcher.js"></script>

  
</body>

</html>