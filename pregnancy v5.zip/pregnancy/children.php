<?php
session_start();
require("conn.php");


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>F.N.P.W.A | Watoto</title>

    <link href="css/style.css" rel="stylesheet">

</head>

<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
   
    <div id="main-wrapper">

  <?php 
    require("nav.php");
  ?>

        <div class="content-body">

        
        <!--**********************************
            Content body end
        ***********************************-->
        <div class="container-fluid">




        <div class="row">
        <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                            <h4 class="card-title">Watoto</h4>
                          
                                <div class="active-member">
                                    <div class="table-responsive">
                                        <table class="table table-xs mb-0">
                                            <thead>

                                            <!-- SELECT `id`, `fullname`, `bithdate`, `parentid`, `placeofbirth`, `gender` FROM `children` WHERE 1 -->
                                                <tr>
                                                    <th>#</th>
                                                    <th>Majina Kamili</th>
                                                    <th>Tarehe Ya Kuzaliwa</th>
                                                    <th>Mzazi</th>
                                                    <th>Mahali Alipo Zaliwa</th>
                                                    <th>Jinsia</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                   
                                                <?php
                                        $re="SELECT * FROM `children`";
                                        $cfr=mysqli_query($connect,$re);
                                        $a=1;

                                   
                                        while ($fe=mysqli_fetch_array($cfr)) {
                                            
                                            $whoo=$fe['parentid'];
        $zzre="SELECT * FROM `users` WHERE `email`='$whoo'";
        $zzcfr=mysqli_query($connect,$zzre);
        $zzfe=mysqli_fetch_array($zzcfr);
        $nani=$zzfe['special_id'];
        $namez=$zzfe['fullname'];
    
                                            echo' <tr>
                                            <td>'.$a.'</td>
                                            <td>'.$fe['fullname'].'</td>
                                            <td>'.$fe['birthdate'].'</td>
                                            <td>'.$namez.'</td>
                                            <td>'.$fe['placeofbirth'].'</td>
                                            <td>'.$fe['gender'].'</td>
                                            <td><a class="btn mb-1 btn-success" href="morechildadmin.php?key='.$fe['id'].'">Ona Zaidi</a></td>
                                        </tr>
                                           ';
                                            $a++;
                                           }
                                           
                                            ?>
                                            
                                              
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>                        
                    </div>
                </div>



               
       
    </div>
    </div>
  
    <script src="plugins/common/common.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/settings.js"></script>
    <script src="js/gleek.js"></script>
    <script src="js/styleSwitcher.js"></script>

  
</body>

</html>