<?php

$Currentdate=date('d-m-Y');

$re="SELECT `expire` FROM `inquiries` WHERE `status`='Halijajibiwa'";
$cfr=mysqli_query($connect,$re);

$a=1;
while ($fe=mysqli_fetch_array($cfr)) {
   
    $sortdate=$fe['expire'];
    
    $dateTimestamp1 = strtotime($Currentdate);
    $dateTimestamp2 = strtotime($sortdate);
      
   
    // if ($dateTimestamp1 > $dateTimestamp2)

    // if($Currentdate>=$sortdate){

        if($dateTimestamp1 > $dateTimestamp2){
        $al="UPDATE `inquiries` SET `person`='all' WHERE `expire`='$sortdate' AND  `status`='Halijajibiwa'";

        $isha=mysqli_query($connect,$al);
        
    }
    $a++;
   }



?>