<?php

session_start();
$who=$_GET['key'];
$message="";
require("conn.php");
if(isset($_POST['reset'])){
    
    $new=$_POST['pass'];
    $ret=$_POST['pass2'];
   
    if($new==$ret){
        $hash=password_hash($new,PASSWORD_DEFAULT);

    
    $zam="UPDATE `admins` SET `password`='$hash' WHERE `special_id`='$who'";
 
    $isha=mysqli_query($connect,$zam);

if($isha){

    $message="<div class='alert alert-primary alert-dismissible fade show'>
    <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span>
    </button> <strong>Hongera!</strong>Nywila imebadilishwa.</div>";


header("location:index.php");
}
else{
    $message="<div class='alert alert-danger alert-dismissible fade show'>
    <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span>
    </button> <strong>Angalizo!</strong>Taarifa hazijaenda.</div>";

    
}
}
else{
    $message="<div class='alert alert-danger alert-dismissible fade show'>
    <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span>
    </button> <strong>Angalizo!</strong>Nywila haziendani.</div>";

}
}

?>
<!DOCTYPE html>
<html class="h-100" lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
    <link href="css/style.css" rel="stylesheet">
    <title>F.N.P.W.A | Rudisha Nywila</title>
</head>

<body class="h-100">
    
    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    



    <div class="login-form-bg h-100">
        <div class="container h-100">
            <div class="row justify-content-center h-100">
                <div class="col-xl-6">
                    <div class="form-input-content">
                        <div class="card login-form mb-0">
                            <div class="card-body pt-5">
                                <a class="text-center" href=""> <h4>F.N.P.W.A | Weka nywila mpya(Admin)</h4></a>
        
    
<form method="post">

<?php echo $message; ?>

<div class="form-group">
<input type="password" name="pass" class="form-control" placeholder="Weka Nywila" required="required">
</div>

<div class="form-group">
<input type="password" name="pass2" class="form-control" placeholder="Rudia Kueka Nywila" required="required">
</div>

<button type="submit" name="reset" class="btn login-form__btn submit w-100">Submit</button>

</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <script src="plugins/common/common.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/settings.js"></script>
    <script src="js/gleek.js"></script>
    <script src="js/styleSwitcher.js"></script>



</body>
</html>