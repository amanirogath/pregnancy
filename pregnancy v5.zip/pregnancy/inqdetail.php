<?php
session_start();
require("conn.php");
$t=$_GET['key'];


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>F.N.P.W.A | Swali na /jibu</title>

    <link href="css/style.css" rel="stylesheet">

</head>

<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10">
            </svg>
        </div>
    </div>
   
    <div id="main-wrapper">

  <?php 
    require("navuser.php");
  ?>

        <div class="content-body">
       
        <div class="container-fluid">


<div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Swali</h4>
                        <div class="basic-form">
                            <form method="post">
                           
                                <div class="form-group">
                               
                                <?php
    //  INSERT INTO `inquiries`(`id`, `title`, `description`, `time`, `status`) VALUES ('[value-1]','[value-2]','[value-3]','[value-4]','[value-5]')

                                $re="SELECT * FROM `inquiries` WHERE `id`='$t'";
                                $er=mysqli_query($connect,$re);
                                $fe=mysqli_fetch_array($er);


                                //majibu
                                // SELECT `id`, `question_id`, `answer`, `time`, `person` FROM `answers` WHERE 1
                                $are="SELECT * FROM `answers` WHERE `question_id`='$t'";
                                $aer=mysqli_query($connect,$are);
                               
                                
                                
                                ?>

                                    <input type="text" class="form-control input-default" name="que"  disabled="disabled" value="Kichwa Cha Habari - <?php echo $fe['title'];?>">
                                </div>
                               
                                <div class="form-group">
                                <label>Swali:</label>
                                    <textarea class="form-control h-150px" rows="6" name="ans" disabled="disabled" id="Swali"><?php echo $fe['description'];?></textarea>
                                </div>

                                <div class="form-group">
                                <label>Majibu:</label>
                                   
                                
                                                                 <?php 
                                                                $a=1;                              
                                                                while( $ade=mysqli_fetch_array($aer)) {
                                                                    echo" <textarea class='form-control h-150px' rows='6' disabled='disabled'>";
                                                                    echo $ade['person']." - ".$ade['time']." - ".$ade['answer'];
                                                                    echo "</textarea>";
                                                                    $a++;
                                                                   }?>
                               
                            
                            </div>
                               
                            </form>
                        </div>
                    </div>
                </div>
             </div>   

             </div>

         </div>

</div>
       


    </div>
</div>
  
    <script src="plugins/common/common.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/settings.js"></script>
    <script src="js/gleek.js"></script>
    <script src="js/styleSwitcher.js"></script>

  
</body>

</html>