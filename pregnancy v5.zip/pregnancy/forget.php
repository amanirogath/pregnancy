<?php
session_start();
$message="";


require("conn.php");
if(isset($_POST['forget'])){
    $acc=mysqli_real_escape_string($connect,trim(htmlspecialchars($_POST['user'])));
   
    $vcal="SELECT `special_id`,`email` FROM `users` WHERE `email`='$acc'";
    $vly=mysqli_query($connect,$vcal);
    $vcou=mysqli_num_rows($vly);


    if($vcou==1){
        $identityf=mysqli_fetch_array($vly);
        $identity=$identityf['special_id'];

//email
require 'PHPMailerAutoload.php';   
$mail = new PHPMailer();
  $mail->IsSMTP();
  $mail->Mailer = "smtp";
  $mail->SMTPDebug = 0;
  $mail->SMTPAuth = TRUE;
  $mail->SMTPSecure = "tls";
  $mail->Port = 587;
  $mail->Host = "smtp.gmail.com";
  $mail->Username = "amarogath94@gmail.com";
  $mail->Password = "djrmyiwwgxhhepwf";

$mail->setFrom('amarogath94@gmail.com', 'F.N.P.W.A');
$mail->addAddress($acc);     // Add a recipient
/*$mail->addAddress('ellen@example.com');*/               // Name is optional
$mail->addReplyTo('amarogath94@gmail.com', 'Kurudisha akaunti | F.N.P.W.A');
    // Optional name
$mail->isHTML(true);                                  // Set email format to HTML

$mail->Subject = 'kurudisha akaunti';
$mail->Body    = '<div>Habari, <br><br>tafathali rudisha akaunti kwa kubonyeza linki ifuatayo</br> <a href="http://localhost/pregnancy/reset.php?key='.$identity.'">Rudisha Nywila</a>.
</div>';
$mail->AltBody = '';
//email end


if(!$mail->send()) {
    echo 'Email could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
  
    $message="<div class='alert alert-primary alert-dismissible fade show'>
    <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span>
    </button> <strong>Hongera!</strong> Linki ya kurudisha akaunti ime tumwa kwenye barua pepe yako.</div>";


}
    }
else{
    $message="<div class='alert alert-danger alert-dismissible fade show'>
    <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span>
    </button> <strong>Angalizo!</strong>Barua pepe hii haipo.</div>";

}

}


?>

<!DOCTYPE html>
<html class="h-100" lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
    <link href="css/style.css" rel="stylesheet">
    <title>F.N.P.W.A | Sahau Nywila</title>
</head>

<body class="h-100">
    
    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    



    <div class="login-form-bg h-100">
        <div class="container h-100">
            <div class="row justify-content-center h-100">
                <div class="col-xl-6">
                    <div class="form-input-content">
                        <div class="card login-form mb-0">
                            <div class="card-body pt-5">
                                <a class="text-center" href=""> <h4>F.N.P.W.A | Rudisha Akaunti</h4></a>
        
    

<form method="post" class="mt-5 mb-5 login-input">
                                    <div class="form-group">
                                    <?php echo $message; ?>
                                    </div>

                                    <div class="form-group">
                                    <input type="email" name="user" class="form-control" placeholder="Barua Pepe" required="required">
                                    </div>

                                   
                                    <button  type="submit" name="forget" class="btn login-form__btn submit w-100">Tuma</button>
                      
<p class="mt-5 login-form__footer"> Mtumiaji wa kawaida? <a href="index.php" class="text-primary">
                                        Ingia</a> &nbsp; | &nbsp; Kiongozi? <a href="adlog.php" class="text-primary">
                                        ingia</a></p>
                               
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <script src="plugins/common/common.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/settings.js"></script>
    <script src="js/gleek.js"></script>
    <script src="js/styleSwitcher.js"></script>



</body>
</html>