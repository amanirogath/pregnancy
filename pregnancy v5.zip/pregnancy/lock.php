<?php
session_start();
require("conn.php");

$who=$_SESSION['who'];

if(empty($_SESSION['who'])){
    header("location:index.php");
    die();

}

$message="";


if(isset($_POST['login'])){
 $user=$who;
    $pass=mysqli_real_escape_string($connect,trim(htmlspecialchars($_POST['pass'])));
    

    $cal="SELECT `special_id`,`email`,`password` FROM `users` WHERE `email`='$user'";
    $ly=mysqli_query($connect,$cal);
    $cou=mysqli_num_rows($ly);
    
    if($cou>0){
    $ff=mysqli_fetch_array($ly);
   
    $pasy=$ff['password'];
  

    $ver=password_verify($pass,$pasy);

    if($ver){
     
        $_SESSION['timestamp'] = time();

        header("location:dashuser.php");

    }
    else {
        $message="<div class='alert alert-warning alert-dismissible fade show'>
        <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span>
        </button> <strong>Angalizo!</strong>Nywila hazifanani.</div>";
    }


}
else{
    header("location:index.php");
}
}


?>
<!DOCTYPE html>
<html class="h-100" lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
    <link href="css/style.css" rel="stylesheet">

    <title>F.N.P.W.A | Ingia tena kwenye mfumo</title>
</head>


<body class="h-100">
    
    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    



    <div class="login-form-bg h-100">
        <div class="container h-100">
            <div class="row justify-content-center h-100">
                <div class="col-xl-6">
                    <div class="form-input-content">
                        <div class="card login-form mb-0">
                            <div class="card-body pt-5">
                                <a class="text-center" href=""> <h4>F.N.P.W.A | weka nywila</h4></a>
        


<form method="post" class="mt-5 mb-5 login-input">
                                    <div class="form-group">
                                    <?php echo $message; ?>
                                    </div>

                                    <div class="form-group">
                                        <input type="email" class="form-control" name="user" value="<?php echo 'Email - '.$_SESSION['who'];?>" disabled="disabled">
                                    </div>

                                    <div class="form-group">
                                        <input type="password" class="form-control" name="pass" placeholder="Nwila">
                                    </div>
                                    <button  type="submit" name="login" class="btn login-form__btn submit w-100">Ingia</button>
                                </form>
                               
                               
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <script src="plugins/common/common.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/settings.js"></script>
    <script src="js/gleek.js"></script>
    <script src="js/styleSwitcher.js"></script>
</body>
</html>