<?php 
session_start();
require("conn.php");

$who=$_SESSION['who'];
if(empty($_SESSION['who'])){
    header("location:index.php");
    die();

}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>F.N.P.W.A | Changamoto</title>
  
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" />
    
    
    <link href="css/style.css" rel="stylesheet">

</head>
<body>


<div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
   

      
    <div id="main-wrapper">

    <?php 
    require("navuser.php");
  ?>

<div class="content-body">
   



<div class="container-fluid">



<h4 class="card-title">Tafathali jibu maswali yafuatayo</h4>

	<div class="block-content mx-4">
                            <form method="post">
                                <div class="row my-2">

                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group  form-group-lg row">
                                            <div class="col-md-12 col-sm-12">
                                                <label for="applicationtype">Leo Unajisikiaje</label>
                                                <select class="form-control" id="atype" name="alevel" required="required">
                                                    <option value="">Chagua</option>
                                                    <option value="g">Najisikia Vizuri</option>
                                                    <option value="b">Najisikia Vibaya</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row" id="blevel" style="display: none;">
                                    <div class="col-md-4">
                                        <div class="form-group  form-group-lg row">
                                            <div class="col-md-12 col-sm-12">
                                                <label for="applicationtype">Umeenda Kliniki?</label>
                                                <select class="form-control" id="btype" name="blevel" required="required">
                                                    <option value="">Chagua</option>
                                                    <option value="n">Ndio</option>
                                                    <option value="h">Hapana</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row" id="clevel" style="display: none;">
                                    <div class="col-md-4">
                                        <div class="form-group  form-group-lg row">
                                            <div class="col-md-12 col-sm-12">
                                                <label for="applicationtype">Chagua Hali Yako</label>
                                                <select class="form-control" id="ctype" name="clevel" required="required">
                                                    <option value="">Chagua</option>
                                                    <option value='al1'>Mzio (Allergy)</option>
                                                    <option value='al2'>Maumivu ya kichwa</option>
                                                    <option value='al3'>Maumivu ya Tumbo</option>
                                                    <option value='al4'>Mwili Kuchoka</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row" id="dlevel" style="display: none;">
                                    <div class="col-md-4">
                                        <div class="form-group  form-group-lg row">
                                            <div class="col-md-12 col-sm-12">
                                                <label for="applicationtype">Allergy Ipi Kati Ya Hizi</label>
                                                <select class="form-control" id="dtype" name="dlevel" required="required">
                                                    <option value="">Chagua</option>
                                                    <option value='all1'>Allergy ya Karanga</option>
                                                    <option value='all2'>Allergy ya Viazi</option>
                                                    <option value='all3'>Allergy ya Nyama ya Ng'ombe</option>
                                                    <option value='all4'>Allergy ya Maziwa</option>
                                                    <option value='all5'>Allergy ya Samaki</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-4">
                                        <p id="message"></p>
                                    </div>
                                </div>
                            </form>
                        </div>







                        
                        </div>
                        </div>
                        </div>






<script src="js/main/jquery.js"></script>
<script src="js/main/main.js"></script>
<script src="js/main/jqueryShower.js"></script>



<script src="plugins/common/common.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/settings.js"></script>
    <script src="js/gleek.js"></script>
    <script src="js/styleSwitcher.js"></script>

</body>
</html>